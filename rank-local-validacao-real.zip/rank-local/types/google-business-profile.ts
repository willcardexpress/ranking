// Tipos normalizados a partir das Business Profile APIs da Google
// (My Business Account Management API + My Business Business Information
// API). Referência oficial, verificada em set/2026:
// https://developers.google.com/my-business/reference/accountmanagement/rest/v1/accounts/list
// https://developers.google.com/my-business/reference/businessinformation/rest/v1/accounts.locations/list
//
// Nunca expor o payload bruto da Google diretamente aos componentes —
// sempre passar por normalizeAccount()/normalizeLocation() em
// services/google/business-profile.ts.

export interface GoogleBusinessAccount {
  /** Nome de recurso, formato "accounts/{id}". */
  resourceName: string;
  accountName: string | null;
  type: string | null;
}

export interface GoogleBusinessLocationHours {
  openDay: string;
  openTime: string;
  closeDay: string;
  closeTime: string;
}

export interface GoogleBusinessLocation {
  /** Nome de recurso, formato "locations/{id}". */
  resourceName: string;
  title: string | null;
  storeCode: string | null;
  primaryCategory: string | null;
  additionalCategories: string[];
  phoneNumbers: string[];
  websiteUri: string | null;
  address: {
    addressLines: string[];
    locality: string | null;
    administrativeArea: string | null;
    postalCode: string | null;
    regionCode: string | null;
  } | null;
  regularHours: GoogleBusinessLocationHours[];
  description: string | null;
  serviceItems: string[];
  /** Link para o perfil no Google Maps, quando disponível. */
  mapsUri: string | null;
  /** Link para a página de avaliação no Google Search, quando disponível. */
  newReviewUri: string | null;
  /** Place ID correspondente (cruza com o módulo de Google Places). */
  placeId: string | null;
  fetchedAt: string;
}

export interface GoogleBusinessTokens {
  accessToken: string;
  refreshToken: string | null;
  expiresAt: string; // ISO timestamp
  scope: string;
}

export type GoogleBusinessConnectionStatus =
  | "not_connected"
  | "connected"
  | "expired"
  | "revoked"
  | "error";

/** Dados de status seguros para exibir na UI — nunca inclui tokens. */
export interface GoogleBusinessConnectionSummary {
  status: GoogleBusinessConnectionStatus;
  googleAccountName: string | null;
  googleAccountResourceName: string | null;
  selectedLocationResourceName: string | null;
  lastSyncedAt: string | null;
  lastError: string | null;
}
