// Tipos de domínio da Fase 1 (Fundação).
// Espelham as tabelas definidas em database/schema.sql.
// Fases futuras adicionarão tipos em arquivos próprios
// (ranking.ts, seo.ts, ai-visibility.ts, content.ts, reputation.ts).

export type OrganizationRole = "owner" | "admin" | "member";

export interface Organization {
  id: string;
  name: string;
  slug: string;
  created_at: string;
  updated_at: string;
}

export interface OrganizationMember {
  id: string;
  organization_id: string;
  user_id: string;
  role: OrganizationRole;
  created_at: string;
}

export type BusinessCategory = string;

export interface Business {
  id: string;
  organization_id: string;
  name: string;
  website: string | null;
  phone: string | null;
  category: BusinessCategory | null;
  keywords: string[];
  service_area: string | null;
  google_place_id: string | null;
  is_demo: boolean;
  created_at: string;
  updated_at: string;
}

export interface BusinessLocation {
  id: string;
  business_id: string;
  address: string;
  city: string;
  state: string;
  country: string;
  latitude: number | null;
  longitude: number | null;
  created_at: string;
  updated_at: string;
}

// --- Métricas exibidas no dashboard (Fase 1: dados mockados/DEMO) ---

export interface DashboardSnapshot {
  business_id: string;
  is_demo: boolean;
  rank_local_index: number; // Índice RankLocal, 0-100 (métrica própria)
  average_observed_position: number | null; // posição observada, nunca "ranking oficial"
  ai_visibility_score: number; // 0-100 (métrica própria)
  seo_score: number; // 0-100 (métrica própria)
  reputation_score: number; // 0-100 (métrica própria)
  monitored_keywords: number;
  generated_at: string;
}
