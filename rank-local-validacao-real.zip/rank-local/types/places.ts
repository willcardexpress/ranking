// Tipos normalizados a partir da Places API (New) da Google.
// Nunca expor o payload bruto da Google diretamente aos componentes —
// sempre passar por normalizePlace() em services/google/places.ts.
// Referência oficial: https://developers.google.com/maps/documentation/places/web-service/text-search
//                      https://developers.google.com/maps/documentation/places/web-service/place-details

export interface NormalizedPlace {
  placeId: string; // campo "id" da resposta da Google
  resourceName: string; // campo "name" (ex: "places/ChIJ...")
  displayName: string;
  formattedAddress: string | null;
  phoneNumber: string | null;
  website: string | null;
  primaryType: string | null;
  types: string[];
  latitude: number | null;
  longitude: number | null;
  rating: number | null;
  userRatingCount: number | null;
  businessStatus: string | null;
  fetchedAt: string; // ISO timestamp de quando os dados foram obtidos
}

export interface PlacesSearchResult {
  places: NormalizedPlace[];
  fromCache: boolean;
}

export interface PlacesServiceError {
  code: "MISSING_API_KEY" | "TIMEOUT" | "RATE_LIMITED" | "UPSTREAM_ERROR" | "INVALID_REQUEST";
  message: string;
}
