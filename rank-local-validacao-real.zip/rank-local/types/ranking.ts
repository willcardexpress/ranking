import type { GridSize } from "@/services/ranking/grid";
import type { RankingTrend } from "@/services/ranking/metrics";

export interface Keyword {
  id: string;
  business_id: string;
  term: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface KeywordLocation {
  id: string;
  keyword_id: string;
  label: string;
  latitude: number;
  longitude: number;
  created_at: string;
}

export type RankingScanStatus = "pending" | "running" | "completed" | "failed";

export interface RankingScan {
  id: string;
  keyword_location_id: string;
  grid_size: GridSize;
  spacing_meters: number;
  search_radius_meters: number;
  max_result_count: number;
  status: RankingScanStatus;
  error_message: string | null;
  requested_by: string | null;
  started_at: string | null;
  completed_at: string | null;
  created_at: string;
}

export interface RankingGridPointRow {
  id: string;
  scan_id: string;
  row_index: number;
  col_index: number;
  latitude: number;
  longitude: number;
}

export interface RankingResultRow {
  id: string;
  grid_point_id: string;
  observed_position: number | null;
  found: boolean;
  top_place_ids: string[];
  fetched_at: string;
}

/** Ponto de grid já combinado com o resultado observado, pronto para a UI. */
export interface GridPointWithResult {
  rowIndex: number;
  colIndex: number;
  latitude: number;
  longitude: number;
  observedPosition: number | null;
  found: boolean;
  fetchedAt: string;
  /** Nome resolvido via cache `places` (pode ser null se ainda não resolvido/expirado). */
  businessName: string | null;
}

export interface ScanSummary {
  scan: RankingScan;
  keyword: Keyword;
  keywordLocation: KeywordLocation;
  points: GridPointWithResult[];
  metrics: {
    totalPoints: number;
    foundPoints: number;
    averagePosition: number | null;
    bestPosition: number | null;
    worstPosition: number | null;
    top3Rate: number;
    top10Rate: number;
  };
  trend: RankingTrend;
  rankLocalIndex: number;
}

export interface CompetitorFrequency {
  placeId: string;
  displayName: string | null;
  appearances: number;
  averagePosition: number;
}
