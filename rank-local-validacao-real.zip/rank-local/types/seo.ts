export interface WebsiteProject {
  id: string;
  business_id: string;
  root_url: string;
  created_at: string;
  updated_at: string;
}

export type SeoAuditStatus = "pending" | "running" | "completed" | "failed";
export type SeoIssueSeverity = "critical" | "warning" | "info";

export interface SeoAudit {
  id: string;
  website_project_id: string;
  status: SeoAuditStatus;
  pages_crawled: number;
  seo_score: number | null;
  has_robots_txt: boolean | null;
  has_sitemap: boolean | null;
  error_message: string | null;
  started_at: string | null;
  completed_at: string | null;
  created_at: string;
}

export interface SeoIssue {
  id: string;
  audit_id: string;
  page_url: string | null;
  issue_type: string;
  severity: SeoIssueSeverity;
  message: string;
}

export interface SeoAuditSummary {
  project: WebsiteProject;
  audit: SeoAudit;
  issues: SeoIssue[];
  issueCountsBySeverity: Record<SeoIssueSeverity, number>;
}
