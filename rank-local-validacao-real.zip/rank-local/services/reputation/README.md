# services/reputation

Análise de avaliações (nota, volume, distribuição, temas via IA). Nunca cria
avaliações falsas nem recomenda manipulação de avaliações.

Implementação prevista junto à Fase 4 (Business Profile).
