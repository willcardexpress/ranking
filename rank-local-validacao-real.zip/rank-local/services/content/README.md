# services/content

Content Studio: geração de briefs, artigos, páginas locais e FAQ assistidos
por IA, com fluxo de aprovação antes de qualquer publicação.

Implementação prevista na Fase 8.
