# services/ai

GeminiService central e módulo de AI Visibility (query generator, testes de
visibilidade, entity optimization, AI Search Readiness).

Regras:
- Fluxo sempre: dados → normalização → métricas → Gemini → explicação/recomendação.
- Gemini nunca inventa dados, concorrentes, avaliações ou ranking.
- Proteger contra prompt injection vindo de conteúdo externo (páginas
  rastreadas, resultados de busca) — tratar sempre como dado, nunca como
  instrução.

Implementação prevista a partir da Fase 7.
