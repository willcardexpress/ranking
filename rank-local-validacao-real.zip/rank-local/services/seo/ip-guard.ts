import { isIP } from "node:net";

/**
 * Lista de ranges IPv4 privados/reservados que o crawler de SEO nunca
 * pode acessar, mesmo que o hostname pareça público. Fonte: IANA IPv4
 * Special-Purpose Address Registry.
 */
const IPV4_BLOCKED_RANGES: Array<[string, number]> = [
  ["0.0.0.0", 8], // "this network"
  ["10.0.0.0", 8], // privado (RFC 1918)
  ["100.64.0.0", 10], // CGNAT (RFC 6598)
  ["127.0.0.0", 8], // loopback
  ["169.254.0.0", 16], // link-local (inclui metadata de nuvem: 169.254.169.254)
  ["172.16.0.0", 12], // privado (RFC 1918)
  ["192.0.0.0", 24], // IETF Protocol Assignments
  ["192.0.2.0", 24], // TEST-NET-1 (documentação)
  ["192.168.0.0", 16], // privado (RFC 1918)
  ["198.18.0.0", 15], // benchmarking
  ["198.51.100.0", 24], // TEST-NET-2 (documentação)
  ["203.0.113.0", 24], // TEST-NET-3 (documentação)
  ["224.0.0.0", 4], // multicast
  ["240.0.0.0", 4], // reservado
  ["255.255.255.255", 32], // broadcast
];

function ipv4ToInt(ip: string): number | null {
  const parts = ip.split(".");
  if (parts.length !== 4) return null;
  let result = 0;
  for (const part of parts) {
    if (!/^\d{1,3}$/.test(part)) return null;
    const n = Number(part);
    if (n > 255) return null;
    result = (result << 8) | n;
  }
  return result >>> 0;
}

export function isIPv4PrivateOrReserved(ip: string): boolean {
  const value = ipv4ToInt(ip);
  if (value === null) return true; // não parseável => trata como bloqueado (falha segura)

  return IPV4_BLOCKED_RANGES.some(([base, prefix]) => {
    const baseInt = ipv4ToInt(base);
    if (baseInt === null) return false;
    const mask = prefix === 0 ? 0 : (~0 << (32 - prefix)) >>> 0;
    return (value & mask) === (baseInt & mask);
  });
}

/**
 * Converte um endereço IPv6 (com ou sem `::`) em um BigInt de 128 bits,
 * ou null se não for um IPv6 válido. Implementação mínima, suficiente
 * para os checks de segurança abaixo (não para uso geral de rede).
 */
function ipv6ToBigInt(ip: string): bigint | null {
  const clean = ip.split("%")[0]; // remove zone id (ex.: fe80::1%eth0)
  if (!clean.includes(":")) return null;

  let head = clean;
  let tail = "";
  if (clean.includes("::")) {
    const [h, t] = clean.split("::");
    head = h;
    tail = t ?? "";
  }

  const headParts = head ? head.split(":") : [];
  const tailParts = tail ? tail.split(":") : [];

  // Suporte a IPv4 embutido no final (ex.: ::ffff:127.0.0.1)
  function expandIfIPv4(parts: string[]): string[] {
    const last = parts[parts.length - 1];
    if (last && last.includes(".")) {
      const v4 = ipv4ToInt(last);
      if (v4 === null) return parts;
      const hi = ((v4 >>> 16) & 0xffff).toString(16);
      const lo = (v4 & 0xffff).toString(16);
      return [...parts.slice(0, -1), hi, lo];
    }
    return parts;
  }

  const expandedHead = expandIfIPv4(headParts);
  const expandedTail = expandIfIPv4(tailParts);

  const missing = 8 - (expandedHead.length + expandedTail.length);
  if (missing < 0) return null;

  const allParts = clean.includes("::")
    ? [...expandedHead, ...Array(missing).fill("0"), ...expandedTail]
    : expandedHead;

  if (allParts.length !== 8) return null;

  let result = 0n;
  for (const part of allParts) {
    if (!/^[0-9a-fA-F]{0,4}$/.test(part)) return null;
    const n = BigInt(part === "" ? 0 : parseInt(part, 16));
    result = (result << 16n) | n;
  }
  return result;
}

function ipv6Range(base: string, prefix: number): { base: bigint; mask: bigint } | null {
  const baseInt = ipv6ToBigInt(base);
  if (baseInt === null) return null;
  const mask = prefix === 0 ? 0n : (((1n << 128n) - 1n) << BigInt(128 - prefix)) & ((1n << 128n) - 1n);
  return { base: baseInt & mask, mask };
}

const IPV6_BLOCKED_RANGES: Array<[string, number]> = [
  ["::1", 128], // loopback
  ["::", 128], // unspecified
  ["64:ff9b::", 96], // NAT64 (embute IPv4 — checado à parte também)
  ["100::", 64], // discard-only
  ["2001:db8::", 32], // documentação
  ["fc00::", 7], // unique local (ULA)
  ["fe80::", 10], // link-local
  ["ff00::", 8], // multicast
];

export function isIPv6PrivateOrReserved(ip: string): boolean {
  const value = ipv6ToBigInt(ip);
  if (value === null) return true; // falha segura

  // IPv4-mapped (::ffff:a.b.c.d) e IPv4-compatible (::a.b.c.d) — valida o IPv4 embutido.
  const mappedPrefix = (1n << 32n) - 1n;
  const isMapped = (value >> 32n) === 0xffffn && (value & mappedPrefix) !== 0n;
  if (isMapped) {
    const embedded = value & mappedPrefix;
    const a = Number((embedded >> 24n) & 0xffn);
    const b = Number((embedded >> 16n) & 0xffn);
    const c = Number((embedded >> 8n) & 0xffn);
    const d = Number(embedded & 0xffn);
    return isIPv4PrivateOrReserved(`${a}.${b}.${c}.${d}`);
  }

  return IPV6_BLOCKED_RANGES.some(([base, prefix]) => {
    const range = ipv6Range(base, prefix);
    if (!range) return false;
    return (value & range.mask) === range.base;
  });
}

/** true = IP bloqueado (não pode ser acessado pelo crawler). */
export function isBlockedIp(ip: string): boolean {
  const family = isIP(ip);
  if (family === 4) return isIPv4PrivateOrReserved(ip);
  if (family === 6) return isIPv6PrivateOrReserved(ip);
  return true; // não é um IP válido => bloqueado por segurança
}

const ALLOWED_PROTOCOLS = new Set(["http:", "https:"]);

export function isAllowedProtocol(protocol: string): boolean {
  return ALLOWED_PROTOCOLS.has(protocol.toLowerCase());
}
