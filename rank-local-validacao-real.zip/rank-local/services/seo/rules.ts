import type { PageSignals } from "./parser";

export type SeoIssueSeverity = "critical" | "warning" | "info";

export interface SeoIssueDraft {
  /** null = problema no nível do site, não de uma página específica. */
  pageUrl: string | null;
  type: string;
  severity: SeoIssueSeverity;
  message: string;
}

const TITLE_MIN = 15;
const TITLE_MAX = 60;
const META_DESCRIPTION_MIN = 50;
const META_DESCRIPTION_MAX = 160;

/**
 * Avalia os sinais de uma única página e retorna os problemas
 * encontrados. Função pura — nenhuma rede, nenhum banco.
 */
export function evaluatePageIssues(signals: PageSignals): SeoIssueDraft[] {
  const issues: SeoIssueDraft[] = [];
  const push = (type: string, severity: SeoIssueSeverity, message: string) =>
    issues.push({ pageUrl: signals.url, type, severity, message });

  if (!signals.isHttps) {
    push("no_https", "critical", "A página não é servida via HTTPS.");
  }

  if (signals.statusCode >= 400) {
    push("page_error_status", "critical", `A página respondeu com status HTTP ${signals.statusCode}.`);
  }

  if (!signals.title) {
    push("missing_title", "critical", "A página não tem tag <title>.");
  } else if (signals.titleLength < TITLE_MIN || signals.titleLength > TITLE_MAX) {
    push(
      "title_length",
      "warning",
      `O título tem ${signals.titleLength} caracteres (ideal entre ${TITLE_MIN} e ${TITLE_MAX}).`
    );
  }

  if (!signals.metaDescription) {
    push("missing_meta_description", "warning", "A página não tem meta description.");
  } else if (
    signals.metaDescriptionLength < META_DESCRIPTION_MIN ||
    signals.metaDescriptionLength > META_DESCRIPTION_MAX
  ) {
    push(
      "meta_description_length",
      "info",
      `A meta description tem ${signals.metaDescriptionLength} caracteres (ideal entre ${META_DESCRIPTION_MIN} e ${META_DESCRIPTION_MAX}).`
    );
  }

  if (signals.h1Count === 0) {
    push("missing_h1", "warning", "A página não tem nenhum H1.");
  } else if (signals.h1Count > 1) {
    push("multiple_h1", "info", `A página tem ${signals.h1Count} tags H1 (o ideal é apenas uma).`);
  }

  if (!signals.canonical) {
    push("missing_canonical", "info", "A página não declara uma URL canônica.");
  }

  if (!signals.hasSchema) {
    push("missing_schema", "info", "A página não tem dados estruturados (JSON-LD).");
  }

  if (!signals.hasOpenGraph) {
    push("missing_open_graph", "info", "A página não tem tags Open Graph.");
  }

  if (signals.imagesTotal > 0 && signals.imagesWithoutAlt > 0) {
    push(
      "images_without_alt",
      "warning",
      `${signals.imagesWithoutAlt} de ${signals.imagesTotal} imagens não têm atributo ALT.`
    );
  }

  if (!signals.hasViewportMeta) {
    push("missing_viewport", "warning", "A página não tem meta viewport (pode prejudicar a experiência mobile).");
  }

  if (signals.wordCount > 0 && signals.wordCount < 150) {
    push("thin_content", "info", `A página tem pouco conteúdo textual (${signals.wordCount} palavras).`);
  }

  if (/[A-Z]/.test(new URL(signals.url).pathname) || signals.url.includes(" ")) {
    push("url_structure", "info", "A URL contém letras maiúsculas ou espaços, o que não é recomendado.");
  }

  return issues;
}

/** Problemas no nível do site (não de uma página específica). */
export function evaluateSiteIssues(input: {
  hasRobotsTxt: boolean;
  hasSitemap: boolean;
  brokenLinks: { url: string; status: number | null }[];
}): SeoIssueDraft[] {
  const issues: SeoIssueDraft[] = [];

  if (!input.hasRobotsTxt) {
    issues.push({
      pageUrl: null,
      type: "missing_robots_txt",
      severity: "warning",
      message: "Não foi encontrado um arquivo robots.txt.",
    });
  }

  if (!input.hasSitemap) {
    issues.push({
      pageUrl: null,
      type: "missing_sitemap",
      severity: "warning",
      message: "Não foi encontrado um sitemap.xml (nem declarado no robots.txt).",
    });
  }

  for (const link of input.brokenLinks) {
    issues.push({
      pageUrl: null,
      type: "broken_internal_link",
      severity: "warning",
      message: `Link interno quebrado: ${link.url}${link.status ? ` (HTTP ${link.status})` : " (sem resposta)"}.`,
    });
  }

  return issues;
}
