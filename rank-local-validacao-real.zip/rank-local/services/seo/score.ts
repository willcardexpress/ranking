import type { SeoIssueDraft } from "./rules";

/**
 * SEO Score — métrica proprietária do RankLocal (0-100), calculada a
 * partir dos problemas encontrados na auditoria. NÃO é o PageSpeed
 * Insights, o Lighthouse Score nem qualquer pontuação oficial da Google —
 * é um cálculo próprio, simples e determinístico, documentado aqui.
 *
 * Fórmula: começa em 100 e desconta por problema encontrado, conforme a
 * severidade (critical -8, warning -3, info -1), com piso em 0.
 */
const WEIGHTS: Record<SeoIssueDraft["severity"], number> = {
  critical: 8,
  warning: 3,
  info: 1,
};

export function computeSeoScore(issues: Pick<SeoIssueDraft, "severity">[]): number {
  const deduction = issues.reduce((sum, issue) => sum + WEIGHTS[issue.severity], 0);
  return Math.max(0, Math.min(100, 100 - deduction));
}
