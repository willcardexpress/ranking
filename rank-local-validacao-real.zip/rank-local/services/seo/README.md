# services/seo

Crawler próprio de auditoria de sites e cálculo do SEO Score (métrica
proprietária). Diferente dos módulos Google, não depende de nenhuma API
de terceiros — ver `docs/seo-audit.md` para as boas práticas de crawling
seguidas (robots.txt, User-Agent próprio, timeouts, rate limiting) e as
limitações desta fase (sem link-following recursivo, sem medição real de
performance/mobile).

## Status: implementado (Fase 5)

- `robots.ts` — parser de robots.txt.
- `parser.ts` — extração de sinais de SEO de uma página HTML (cheerio).
- `rules.ts` — regras que transformam sinais em problemas encontrados.
- `score.ts` — SEO Score (0-100, proprietário).
- `rate-limiter.ts` / `errors.ts` — mesmo padrão dos módulos Google, mas
  independentes (arquitetura separada por integração).
- `crawler.ts` — orquestrador (busca robots.txt, sitemap, páginas e
  verifica links quebrados).

Toda a persistência (banco) e exposição para a UI ficam em
`lib/actions/seo.ts` e `lib/seo-data.ts`, não aqui.
