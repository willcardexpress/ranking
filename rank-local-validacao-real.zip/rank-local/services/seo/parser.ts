import * as cheerio from "cheerio";

/**
 * Sinais extraídos de uma página HTML já baixada. Puro — não faz
 * requisição nenhuma, só interpreta o HTML recebido. Testável sem rede.
 */
export interface PageSignals {
  url: string;
  statusCode: number;
  isHttps: boolean;
  title: string | null;
  titleLength: number;
  metaDescription: string | null;
  metaDescriptionLength: number;
  h1Count: number;
  h1Texts: string[];
  h2Count: number;
  canonical: string | null;
  hasSchema: boolean;
  hasOpenGraph: boolean;
  imagesTotal: number;
  imagesWithoutAlt: number;
  internalLinks: string[];
  wordCount: number;
  hasViewportMeta: boolean;
}

export function parseHtml(url: string, statusCode: number, html: string): PageSignals {
  const $ = cheerio.load(html);
  const origin = safeOrigin(url);

  const title = clean($("title").first().text());
  const metaDescription = clean($('meta[name="description"]').first().attr("content") ?? null);
  const canonical = $('link[rel="canonical"]').first().attr("href") ?? null;
  const hasSchema = $('script[type="application/ld+json"]').length > 0;
  const hasOpenGraph = $('meta[property^="og:"]').length > 0;
  const hasViewportMeta = $('meta[name="viewport"]').length > 0;

  const h1Texts = $("h1")
    .map((_, el) => clean($(el).text()))
    .get()
    .filter((t): t is string => Boolean(t));

  const images = $("img");
  const imagesWithoutAlt = images
    .filter((_, el) => !$(el).attr("alt")?.trim())
    .toArray().length;

  const internalLinks = new Set<string>();
  $("a[href]").each((_, el) => {
    const href = $(el).attr("href");
    if (!href) return;
    const resolved = resolveInternalUrl(href, url, origin);
    if (resolved) internalLinks.add(resolved);
  });

  const bodyText = clean($("body").text()) ?? "";
  const wordCount = bodyText.length === 0 ? 0 : bodyText.split(/\s+/).filter(Boolean).length;

  return {
    url,
    statusCode,
    isHttps: url.startsWith("https://"),
    title,
    titleLength: title?.length ?? 0,
    metaDescription,
    metaDescriptionLength: metaDescription?.length ?? 0,
    h1Count: h1Texts.length,
    h1Texts,
    h2Count: $("h2").length,
    canonical,
    hasSchema,
    hasOpenGraph,
    imagesTotal: images.length,
    imagesWithoutAlt,
    internalLinks: Array.from(internalLinks),
    wordCount,
    hasViewportMeta,
  };
}

function clean(text: string | null | undefined): string | null {
  if (!text) return null;
  const trimmed = text.replace(/\s+/g, " ").trim();
  return trimmed.length > 0 ? trimmed : null;
}

function safeOrigin(url: string): string | null {
  try {
    return new URL(url).origin;
  } catch {
    return null;
  }
}

function resolveInternalUrl(href: string, baseUrl: string, origin: string | null): string | null {
  if (!origin) return null;
  if (href.startsWith("#") || href.startsWith("mailto:") || href.startsWith("tel:") || href.startsWith("javascript:")) {
    return null;
  }
  try {
    const resolved = new URL(href, baseUrl);
    if (resolved.origin !== origin) return null;
    resolved.hash = "";
    return resolved.toString();
  } catch {
    return null;
  }
}
