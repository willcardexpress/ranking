export type SeoErrorCode =
  | "INVALID_URL"
  | "ROBOTS_DISALLOWED"
  | "TIMEOUT"
  | "RATE_LIMITED"
  | "INTERNAL_RATE_LIMITED"
  | "UPSTREAM_ERROR"
  | "NO_PAGES_CRAWLED"
  | "SSRF_BLOCKED"
  | "TOO_MANY_REDIRECTS";

export class SeoServiceError extends Error {
  code: SeoErrorCode;

  constructor(code: SeoErrorCode, message: string) {
    super(message);
    this.name = "SeoServiceError";
    this.code = code;
  }
}
