import { SeoServiceError } from "./errors";
import { checkDbRateLimit, RateLimitExceededError } from "@/lib/rate-limit";

/**
 * Rate limiting interno do crawler de SEO — duas camadas (mesmo desenho
 * de services/google/rate-limiter.ts; ver lib/rate-limit.ts para o
 * porquê): janela fixa em memória por processo (rápida, primeira linha
 * de defesa) + contador compartilhado no Postgres (limite real entre
 * instâncias, falha aberta se o banco estiver indisponível).
 * Independente e separado do rate limiter dos módulos Google — ver
 * docs/architecture.md: "Separar completamente ... Crawler SEO ...".
 */

interface Window {
  startedAt: number;
  count: number;
}

const WINDOW_MS = 60_000;

const LIMITS = {
  audit: 10, // auditorias completas iniciadas por minuto
  page_fetch: 120, // páginas/robots.txt/sitemap buscados por minuto
} as const;

const windows = new Map<keyof typeof LIMITS, Window>();

export async function checkSeoRateLimit(operation: keyof typeof LIMITS): Promise<void> {
  const limit = LIMITS[operation];
  const now = Date.now();
  const current = windows.get(operation);

  if (!current || now - current.startedAt > WINDOW_MS) {
    windows.set(operation, { startedAt: now, count: 1 });
  } else {
    current.count += 1;

    if (current.count > limit) {
      throw new SeoServiceError(
        "INTERNAL_RATE_LIMITED",
        `Limite interno de ${limit} requisições/minuto para "${operation}" foi excedido. Aguarde um instante.`
      );
    }
  }

  try {
    await checkDbRateLimit(`seo:${operation}`, limit, WINDOW_MS);
  } catch (error) {
    if (error instanceof RateLimitExceededError) {
      throw new SeoServiceError(
        "INTERNAL_RATE_LIMITED",
        `Limite de ${limit} requisições/minuto para "${operation}" foi excedido (entre todas as instâncias). Aguarde um instante.`
      );
    }
    throw error;
  }
}

export function resetSeoRateLimits(): void {
  windows.clear();
}
