/**
 * Parser minimo de robots.txt - le apenas as regras que se aplicam ao
 * user-agent geral ("*"), que e o que usamos (nosso crawler se identifica
 * como "RankLocalBot"; na ausencia de um bloco especifico para ele,
 * seguimos as regras de "*", pratica padrao da maioria dos crawlers).
 * Suficiente para a auditoria de SEO - nao e um parser completo da
 * especificacao (nao trata `Allow` com prioridade fina nem wildcards
 * complexos), mas cobre o caso comum de `Disallow` por prefixo de path.
 */

export interface RobotsRules {
  disallowedPaths: string[];
  sitemapUrls: string[];
}

export function parseRobotsTxt(content: string): RobotsRules {
  const lines = content.split("\n").map((l) => l.trim());
  const disallowedPaths: string[] = [];
  const sitemapUrls: string[] = [];

  let inWildcardBlock = false;
  let sawAnyUserAgent = false;

  for (const rawLine of lines) {
    const line = rawLine.split("#")[0].trim();
    if (!line) continue;

    const [rawKey, ...rest] = line.split(":");
    const key = rawKey.trim().toLowerCase();
    const value = rest.join(":").trim();

    if (key === "sitemap" && value) {
      sitemapUrls.push(value);
      continue;
    }

    if (key === "user-agent") {
      sawAnyUserAgent = true;
      inWildcardBlock = value === "*";
      continue;
    }

    if (key === "disallow" && inWildcardBlock) {
      if (value) disallowedPaths.push(value);
      continue;
    }
  }

  if (!sawAnyUserAgent) {
    return { disallowedPaths: [], sitemapUrls };
  }

  return { disallowedPaths, sitemapUrls };
}

export function isPathAllowed(rules: RobotsRules, path: string): boolean {
  return !rules.disallowedPaths.some((disallowed) => path.startsWith(disallowed));
}
