import "server-only";
import * as cheerio from "cheerio";
import { createScopedLogger } from "@/services/google/logger";
import { checkSeoRateLimit } from "./rate-limiter";
import { SeoServiceError } from "./errors";
import { safeFetch } from "./safe-fetch";
import { parseRobotsTxt, isPathAllowed, type RobotsRules } from "./robots";
import { parseHtml, type PageSignals } from "./parser";
import { evaluatePageIssues, evaluateSiteIssues, type SeoIssueDraft } from "./rules";
import { computeSeoScore } from "./score";

/**
 * SeoCrawlerService — crawler próprio do RankLocal.
 *
 * Diferente dos módulos Google, aqui não há API oficial nem termos de
 * terceiros a verificar: estamos buscando o site que o próprio usuário
 * cadastrou para auditoria. Ainda assim, seguimos boas práticas
 * obrigatórias de um crawler responsável:
 * - Respeita robots.txt (não busca paths em Disallow para "*").
 * - Se identifica com um User-Agent próprio e honesto.
 * - **Toda requisição passa por `safeFetch` (services/seo/safe-fetch.ts)**,
 *   que bloqueia SSRF: resolve o hostname para IP, recusa endereços
 *   privados/loopback/link-local/reservados (inclusive o metadata de
 *   nuvem 169.254.169.254), pina esse IP na conexão real (evitando DNS
 *   rebinding), nunca segue redirect automaticamente e revalida cada
 *   redirect do zero antes de seguir. Ver docs/seo-audit.md.
 * - Rate limiting interno (services/seo/rate-limiter.ts).
 * - Escopo de páginas limitado (MAX_PAGES) para caber no tempo de uma
 *   Server Action e não sobrecarregar o site auditado.
 *
 * Limitações desta fase (documentadas em docs/seo-audit.md):
 * - Sem link-following recursivo: só audita a home + páginas listadas no
 *   sitemap.xml (até MAX_PAGES). Sem sitemap, audita só a home.
 * - "Mobile" é verificado apenas pela presença de <meta viewport> — não
 *   há renderização real em diferentes tamanhos de tela.
 * - "Performance" não é medida nesta fase (exigiria um navegador real).
 * - Sites que dependem de JavaScript para renderizar conteúdo (SPAs) são
 *   vistos apenas pelo HTML inicial, sem execução de JS.
 */

const USER_AGENT = "RankLocalBot/1.0 (+https://ranklocal.example/bot; auditoria de SEO solicitada pelo proprietário do site)";
const PAGE_TIMEOUT_MS = 8000;
const MAX_PAGES = 15;
const MAX_BROKEN_LINK_CHECKS = 20;

const logger = createScopedLogger("seo.crawler");

export interface CrawlResult {
  rootUrl: string;
  pages: PageSignals[];
  issues: SeoIssueDraft[];
  seoScore: number;
  hasRobotsTxt: boolean;
  hasSitemap: boolean;
}

/**
 * safeFetch com um retry simples para falhas transitórias (rede/timeout).
 * Nunca retenta erros de bloqueio de segurança (SSRF_BLOCKED, INVALID_URL,
 * TOO_MANY_REDIRECTS) — esses são permanentes e retentar não ajudaria.
 */
async function guardedFetch(
  url: string,
  init: { method?: string; headers?: Record<string, string>; timeoutMs?: number }
): Promise<Response> {
  try {
    return await safeFetch(url, init);
  } catch (error) {
    if (
      error instanceof SeoServiceError &&
      (error.code === "SSRF_BLOCKED" || error.code === "INVALID_URL" || error.code === "TOO_MANY_REDIRECTS")
    ) {
      throw error;
    }
    // uma única nova tentativa para falhas transitórias
    return await safeFetch(url, init);
  }
}

export class SeoCrawlerService {
  async auditWebsite(rootUrl: string): Promise<CrawlResult> {
    const normalizedRoot = this.normalizeUrl(rootUrl);
    await checkSeoRateLimit("audit");

    const robots = await this.fetchRobots(normalizedRoot);
    const sitemapUrls = robots ? await this.expandSitemaps(robots.sitemapUrls, normalizedRoot) : [];

    const candidateUrls = Array.from(new Set([normalizedRoot, ...sitemapUrls])).slice(0, MAX_PAGES);

    const pages: PageSignals[] = [];
    for (const url of candidateUrls) {
      if (robots && !isPathAllowed(robots, this.pathOf(url))) {
        logger.info("page skipped by robots.txt", { url });
        continue;
      }
      const signals = await this.fetchAndParsePage(url);
      if (signals) pages.push(signals);
    }

    if (pages.length === 0) {
      throw new SeoServiceError("NO_PAGES_CRAWLED", "Não foi possível carregar nenhuma página deste site.");
    }

    const allInternalLinks = Array.from(new Set(pages.flatMap((p) => p.internalLinks))).slice(
      0,
      MAX_BROKEN_LINK_CHECKS
    );
    const brokenLinks = await this.checkBrokenLinks(allInternalLinks);

    const pageIssues = pages.flatMap(evaluatePageIssues);
    const siteIssues = evaluateSiteIssues({
      hasRobotsTxt: Boolean(robots),
      hasSitemap: sitemapUrls.length > 0,
      brokenLinks,
    });
    const issues = [...siteIssues, ...pageIssues];

    return {
      rootUrl: normalizedRoot,
      pages,
      issues,
      seoScore: computeSeoScore(issues),
      hasRobotsTxt: Boolean(robots),
      hasSitemap: sitemapUrls.length > 0,
    };
  }

  private normalizeUrl(input: string): string {
    let url = input.trim();
    if (!/^https?:\/\//i.test(url)) url = `https://${url}`;
    try {
      const parsed = new URL(url);
      return parsed.toString();
    } catch {
      throw new SeoServiceError("INVALID_URL", "URL do site inválida.");
    }
  }

  private pathOf(url: string): string {
    try {
      return new URL(url).pathname;
    } catch {
      return "/";
    }
  }

  private async fetchRobots(rootUrl: string): Promise<RobotsRules | null> {
    try {
      await checkSeoRateLimit("page_fetch");
      const robotsUrl = new URL("/robots.txt", rootUrl).toString();
      const response = await guardedFetch(robotsUrl, {
        headers: { "User-Agent": USER_AGENT },
        timeoutMs: PAGE_TIMEOUT_MS,
      });
      if (!response.ok) return null;
      const text = await response.text();
      return parseRobotsTxt(text);
    } catch {
      return null;
    }
  }

  private async expandSitemaps(sitemapUrls: string[], rootUrl: string): Promise<string[]> {
    const urlsToTry = sitemapUrls.length > 0 ? sitemapUrls : [new URL("/sitemap.xml", rootUrl).toString()];
    const collected: string[] = [];

    for (const sitemapUrl of urlsToTry.slice(0, 2)) {
      try {
        await checkSeoRateLimit("page_fetch");
        const response = await guardedFetch(sitemapUrl, {
          headers: { "User-Agent": USER_AGENT },
          timeoutMs: PAGE_TIMEOUT_MS,
        });
        if (!response.ok) continue;
        const xml = await response.text();
        const $ = cheerio.load(xml, { xmlMode: true });
        $("loc").each((_, el) => {
          const loc = $(el).text().trim();
          if (loc) collected.push(loc);
        });
      } catch {
        continue;
      }
    }

    return collected;
  }

  private async fetchAndParsePage(url: string): Promise<PageSignals | null> {
    try {
      await checkSeoRateLimit("page_fetch");
      const response = await guardedFetch(url, {
        headers: { "User-Agent": USER_AGENT },
        timeoutMs: PAGE_TIMEOUT_MS,
      });
      const html = await response.text();
      return parseHtml(url, response.status, html);
    } catch (error) {
      logger.warn("page fetch failed", { url, errorName: error instanceof Error ? error.name : "unknown" });
      return null;
    }
  }

  private async checkBrokenLinks(urls: string[]): Promise<{ url: string; status: number | null }[]> {
    const broken: { url: string; status: number | null }[] = [];

    for (const url of urls) {
      try {
        await checkSeoRateLimit("page_fetch");
        const response = await safeFetch(url, {
          method: "HEAD",
          headers: { "User-Agent": USER_AGENT },
          timeoutMs: PAGE_TIMEOUT_MS,
        });
        if (response.status >= 400) {
          broken.push({ url, status: response.status });
        }
      } catch {
        broken.push({ url, status: null });
      }
    }

    return broken;
  }
}

export const seoCrawlerService = new SeoCrawlerService();
export { SeoServiceError } from "./errors";
