import "server-only";
import { lookup as dnsLookup } from "node:dns/promises";
import { Agent, fetch as undiciFetch } from "undici";
import { isBlockedIp, isAllowedProtocol } from "./ip-guard";
import { SeoServiceError } from "./errors";
import { createScopedLogger } from "@/services/google/logger";

/**
 * safeFetch - a UNICA forma permitida de buscar uma URL fornecida pelo
 * usuario (site a ser auditado) neste modulo. Protege contra SSRF:
 *
 * 1. So aceita http/https (bloqueia file:, ftp:, data:, gopher:, etc.).
 * 2. Resolve o hostname para IP via DNS *antes* de conectar, e valida
 *    esse IP contra loopback/privado/link-local/reservado (services/seo/ip-guard.ts).
 * 3. Protecao contra DNS rebinding: o IP validado no passo 2 e o MESMO
 *    IP usado na conexao TCP real (via Agent do undici com
 *    connect.lookup fixado no IP ja validado) - nunca deixamos o socket
 *    fazer uma nova resolucao de DNS por conta propria entre a validacao
 *    e a conexao, que e exatamente a janela que um atacante de DNS
 *    rebinding exploraria (DNS responde um IP publico na checagem e um
 *    IP privado poucos segundos depois, no momento da conexao real).
 * 4. Redirects nunca sao seguidos automaticamente (redirect: "manual");
 *    cada redirect e resolvido, revalidado do zero (protocolo + DNS + IP)
 *    e so entao seguido, ate um limite de redirects.
 *
 * Usado por services/seo/crawler.ts para robots.txt, sitemap.xml, cada
 * pagina rastreada e a checagem de links internos quebrados - ou seja,
 * toda requisicao de rede deste modulo passa por aqui.
 */

const MAX_REDIRECTS = 5;
const DEFAULT_TIMEOUT_MS = 8000;
const REDIRECT_STATUS_CODES = new Set([301, 302, 303, 307, 308]);

const logger = createScopedLogger("seo.safe-fetch");

interface SafeFetchOptions {
  method?: string;
  headers?: Record<string, string>;
  timeoutMs?: number;
}

export async function resolveAndValidate(hostname: string): Promise<{ address: string; family: 4 | 6 }> {
  let result: { address: string; family: number };
  try {
    result = await dnsLookup(hostname, { verbatim: true });
  } catch {
    throw new SeoServiceError("SSRF_BLOCKED", `Nao foi possivel resolver o endereco de "${hostname}".`);
  }

  if (isBlockedIp(result.address)) {
    logger.warn("blocked SSRF attempt", { hostname, resolvedFamily: result.family });
    throw new SeoServiceError(
      "SSRF_BLOCKED",
      `O host "${hostname}" resolve para um endereco privado/reservado e nao pode ser auditado.`
    );
  }

  return { address: result.address, family: result.family === 6 ? 6 : 4 };
}

/**
 * Checagem de conveniência para validar a URL no momento em que o usuário
 * a cadastra (feedback imediato), além da checagem que já acontece,
 * sempre, dentro de safeFetch a cada requisição real do crawler — essa
 * segunda é a que efetivamente protege contra SSRF; esta aqui só evita
 * que o usuário só descubra o problema ao clicar em "Rodar auditoria".
 */
export async function assertHostnameIsPublic(hostname: string): Promise<void> {
  await resolveAndValidate(hostname);
}

function assertSafeUrl(url: URL): void {
  if (!isAllowedProtocol(url.protocol)) {
    throw new SeoServiceError("SSRF_BLOCKED", `Protocolo "${url.protocol}" nao e permitido (so http/https).`);
  }
}

async function fetchOnce(url: URL, pinnedIp: string, family: 4 | 6, options: SafeFetchOptions): Promise<Response> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), options.timeoutMs ?? DEFAULT_TIMEOUT_MS);

  const agent = new Agent({
    connect: {
      lookup: (_hostname, _opts, callback) => {
        callback(null, [{ address: pinnedIp, family }]);
      },
    },
  });

  try {
    const response = await undiciFetch(url.toString(), {
      method: options.method ?? "GET",
      headers: options.headers,
      redirect: "manual",
      signal: controller.signal,
      dispatcher: agent,
    });
    return response as unknown as Response;
  } finally {
    clearTimeout(timeout);
    await agent.close();
  }
}

export async function safeFetch(inputUrl: string, options: SafeFetchOptions = {}): Promise<Response> {
  let currentUrl: URL;
  try {
    currentUrl = new URL(inputUrl);
  } catch {
    throw new SeoServiceError("INVALID_URL", "URL invalida.");
  }

  for (let redirectCount = 0; redirectCount <= MAX_REDIRECTS; redirectCount++) {
    assertSafeUrl(currentUrl);
    const { address, family } = await resolveAndValidate(currentUrl.hostname);

    const response = await fetchOnce(currentUrl, address, family, options);

    if (!REDIRECT_STATUS_CODES.has(response.status)) {
      return response;
    }

    if (redirectCount === MAX_REDIRECTS) {
      throw new SeoServiceError("TOO_MANY_REDIRECTS", `Mais de ${MAX_REDIRECTS} redirecionamentos.`);
    }

    const location = response.headers.get("location");
    if (!location) {
      return response;
    }

    try {
      currentUrl = new URL(location, currentUrl);
    } catch {
      throw new SeoServiceError("SSRF_BLOCKED", "Redirecionamento para uma URL invalida.");
    }
  }

  throw new SeoServiceError("TOO_MANY_REDIRECTS", "Limite de redirecionamentos excedido.");
}
