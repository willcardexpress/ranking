export type GoogleBusinessProfileErrorCode =
  | "MISSING_OAUTH_CONFIG"
  | "NOT_CONNECTED"
  | "INVALID_STATE"
  | "TOKEN_EXCHANGE_FAILED"
  | "TOKEN_EXPIRED"
  | "TOKEN_REVOKED"
  | "PERMISSION_DENIED"
  | "RATE_LIMITED"
  | "INTERNAL_RATE_LIMITED"
  | "UPSTREAM_ERROR"
  | "INVALID_REQUEST";

export class GoogleBusinessProfileError extends Error {
  code: GoogleBusinessProfileErrorCode;

  constructor(code: GoogleBusinessProfileErrorCode, message: string) {
    super(message);
    this.name = "GoogleBusinessProfileError";
    this.code = code;
  }
}
