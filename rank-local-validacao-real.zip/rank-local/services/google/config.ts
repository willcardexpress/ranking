/**
 * Checagem de configuração da integração com o Google Places.
 * Usado tanto pelo serviço (para recusar chamadas sem chave) quanto pela UI
 * (para mostrar "Google Places não conectado" em vez de tentar buscar e
 * falhar silenciosamente).
 */
export function isGooglePlacesConfigured(): boolean {
  return Boolean(process.env.GOOGLE_PLACES_API_KEY?.trim());
}

/**
 * Checagem de configuração do OAuth do Google Business Profile (Fase 4).
 * Reaproveita as variáveis já reservadas desde a Fase 1 (.env.example):
 * GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_OAUTH_REDIRECT_URI —
 * mais GBP_OAUTH_STATE_SECRET (segredo dedicado para assinar o `state`
 * do OAuth, corrigido após auditoria: antes reaproveitava
 * SUPABASE_SERVICE_ROLE_KEY).
 *
 * Importante: mesmo com essas variáveis configuradas, a Business
 * Profile API só funciona de fato depois que a Google aprova manualmente
 * o acesso do projeto ("Basic API Access") — sem essa aprovação, todas as
 * chamadas retornam erro de permissão (cota 0 req/min). Essa checagem
 * cobre só a configuração local; ver services/google/business-profile.ts
 * para como o erro de permissão da Google é tratado e exibido.
 */
export function isGoogleBusinessProfileConfigured(): boolean {
  return Boolean(
    process.env.GOOGLE_CLIENT_ID?.trim() &&
      process.env.GOOGLE_CLIENT_SECRET?.trim() &&
      process.env.GOOGLE_OAUTH_REDIRECT_URI?.trim() &&
      process.env.GBP_OAUTH_STATE_SECRET?.trim()
  );
}
