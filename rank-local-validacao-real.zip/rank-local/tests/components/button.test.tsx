import { describe, expect, it, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { Button } from "@/components/ui/button";

describe("<Button />", () => {
  it("renderiza o texto informado", () => {
    render(<Button>Salvar empresa</Button>);
    expect(screen.getByRole("button", { name: "Salvar empresa" })).toBeInTheDocument();
  });

  it("dispara onClick quando clicado", () => {
    const onClick = vi.fn();
    render(<Button onClick={onClick}>Entrar</Button>);
    fireEvent.click(screen.getByRole("button", { name: "Entrar" }));
    expect(onClick).toHaveBeenCalledTimes(1);
  });

  it("fica desabilitado quando disabled=true", () => {
    render(<Button disabled>Buscar</Button>);
    expect(screen.getByRole("button", { name: "Buscar" })).toBeDisabled();
  });
});
