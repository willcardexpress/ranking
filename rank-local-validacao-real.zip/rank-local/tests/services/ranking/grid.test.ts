import { describe, expect, it } from "vitest";
import { generateGridPoints, gridDimension, suggestedSearchRadius } from "@/services/ranking/grid";

const CENTER = { latitude: -15.8267, longitude: -47.9218 }; // Brasília, DF

describe("generateGridPoints", () => {
  it("gera 9 pontos para grid 3x3", () => {
    const points = generateGridPoints(CENTER, "3x3", 500);
    expect(points).toHaveLength(9);
  });

  it("gera 25 pontos para grid 5x5", () => {
    const points = generateGridPoints(CENTER, "5x5", 500);
    expect(points).toHaveLength(25);
  });

  it("gera 49 pontos para grid 7x7", () => {
    const points = generateGridPoints(CENTER, "7x7", 500);
    expect(points).toHaveLength(49);
  });

  it("o ponto central do grid coincide com o centro informado", () => {
    const points = generateGridPoints(CENTER, "3x3", 500);
    const center = points.find((p) => p.rowIndex === 1 && p.colIndex === 1);
    expect(center?.latitude).toBeCloseTo(CENTER.latitude, 6);
    expect(center?.longitude).toBeCloseTo(CENTER.longitude, 6);
  });

  it("rowIndex e colIndex começam em 0 e vão até dimension-1", () => {
    const points = generateGridPoints(CENTER, "5x5", 300);
    const rows = new Set(points.map((p) => p.rowIndex));
    const cols = new Set(points.map((p) => p.colIndex));
    expect(Math.min(...rows)).toBe(0);
    expect(Math.max(...rows)).toBe(4);
    expect(Math.min(...cols)).toBe(0);
    expect(Math.max(...cols)).toBe(4);
  });

  it("lança erro para spacing inválido", () => {
    expect(() => generateGridPoints(CENTER, "3x3", 0)).toThrow();
    expect(() => generateGridPoints(CENTER, "3x3", -10)).toThrow();
  });

  it("todos os pontos têm coordenadas distintas", () => {
    const points = generateGridPoints(CENTER, "5x5", 500);
    const unique = new Set(points.map((p) => `${p.latitude},${p.longitude}`));
    expect(unique.size).toBe(points.length);
  });
});

describe("gridDimension", () => {
  it("mapeia corretamente cada tamanho de grid", () => {
    expect(gridDimension("3x3")).toBe(3);
    expect(gridDimension("5x5")).toBe(5);
    expect(gridDimension("7x7")).toBe(7);
  });
});

describe("suggestedSearchRadius", () => {
  it("sugere metade do espaçamento, com piso de 150m", () => {
    expect(suggestedSearchRadius(1000)).toBe(500);
    expect(suggestedSearchRadius(200)).toBe(150);
  });
});
