import { describe, expect, it } from "vitest";
import { computeRankingMetrics, computeTrend } from "@/services/ranking/metrics";

describe("computeRankingMetrics", () => {
  it("calcula posição média, melhor e pior apenas entre pontos encontrados", () => {
    const metrics = computeRankingMetrics([
      { position: 1 },
      { position: 5 },
      { position: null },
      { position: 9 },
    ]);

    expect(metrics.totalPoints).toBe(4);
    expect(metrics.foundPoints).toBe(3);
    expect(metrics.averagePosition).toBeCloseTo(5, 1); // (1+5+9)/3 = 5
    expect(metrics.bestPosition).toBe(1);
    expect(metrics.worstPosition).toBe(9);
  });

  it("calcula top3Rate e top10Rate sobre o total de pontos (não só os encontrados)", () => {
    const metrics = computeRankingMetrics([
      { position: 1 }, // top3 e top10
      { position: 8 }, // só top10
      { position: null }, // nenhum
      { position: 15 }, // nenhum (fora do top10)
    ]);

    expect(metrics.top3Rate).toBeCloseTo(25, 1); // 1/4
    expect(metrics.top10Rate).toBeCloseTo(50, 1); // 2/4
  });

  it("retorna métricas nulas quando nenhum ponto foi encontrado", () => {
    const metrics = computeRankingMetrics([{ position: null }, { position: null }]);
    expect(metrics.averagePosition).toBeNull();
    expect(metrics.bestPosition).toBeNull();
    expect(metrics.worstPosition).toBeNull();
    expect(metrics.top3Rate).toBe(0);
    expect(metrics.top10Rate).toBe(0);
  });

  it("lida com lista vazia sem lançar erro", () => {
    const metrics = computeRankingMetrics([]);
    expect(metrics.totalPoints).toBe(0);
    expect(metrics.top3Rate).toBe(0);
  });
});

describe("computeTrend", () => {
  it("retorna 'melhorou' quando a posição média cai", () => {
    expect(computeTrend(2, 6)).toBe("melhorou");
  });

  it("retorna 'piorou' quando a posição média sobe", () => {
    expect(computeTrend(8, 3)).toBe("piorou");
  });

  it("retorna 'estavel' para diferenças dentro do epsilon", () => {
    expect(computeTrend(5, 5.1)).toBe("estavel");
  });

  it("retorna 'indisponivel' quando falta um dos dois valores", () => {
    expect(computeTrend(null, 5)).toBe("indisponivel");
    expect(computeTrend(5, null)).toBe("indisponivel");
    expect(computeTrend(null, null)).toBe("indisponivel");
  });
});
