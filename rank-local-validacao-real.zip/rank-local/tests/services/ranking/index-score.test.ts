import { describe, expect, it } from "vitest";
import { computeRankLocalIndex } from "@/services/ranking/index-score";

describe("computeRankLocalIndex", () => {
  it("retorna 100 quando presenca e total no Top 3 e posicao media e 1", () => {
    const score = computeRankLocalIndex({
      top3Rate: 100,
      top10Rate: 100,
      averagePosition: 1,
      maxResultCount: 20,
    });
    expect(score).toBe(100);
  });

  it("retorna 0 quando a empresa nunca foi encontrada", () => {
    const score = computeRankLocalIndex({
      top3Rate: 0,
      top10Rate: 0,
      averagePosition: null,
      maxResultCount: 20,
    });
    expect(score).toBe(0);
  });

  it("fica entre 0 e 100 para cenarios intermediarios", () => {
    const score = computeRankLocalIndex({
      top3Rate: 40,
      top10Rate: 70,
      averagePosition: 6,
      maxResultCount: 20,
    });
    expect(score).toBeGreaterThan(0);
    expect(score).toBeLessThan(100);
  });

  it("penaliza posicao media pior mantendo top3/top10 constantes", () => {
    const better = computeRankLocalIndex({
      top3Rate: 50,
      top10Rate: 50,
      averagePosition: 2,
      maxResultCount: 20,
    });
    const worse = computeRankLocalIndex({
      top3Rate: 50,
      top10Rate: 50,
      averagePosition: 15,
      maxResultCount: 20,
    });
    expect(better).toBeGreaterThan(worse);
  });

  it("nunca retorna valor fora de 0-100 mesmo com entradas extremas", () => {
    const score = computeRankLocalIndex({
      top3Rate: 100,
      top10Rate: 100,
      averagePosition: 1,
      maxResultCount: 1,
    });
    expect(score).toBeGreaterThanOrEqual(0);
    expect(score).toBeLessThanOrEqual(100);
  });
});
