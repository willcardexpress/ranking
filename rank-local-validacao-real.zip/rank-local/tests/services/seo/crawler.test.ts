import { describe, expect, it, vi, beforeEach } from "vitest";

vi.mock("server-only", () => ({}));

const safeFetchMock = vi.fn();
vi.mock("@/services/seo/safe-fetch", () => ({
  safeFetch: (...a: unknown[]) => safeFetchMock(...a),
}));

import { resetSeoRateLimits } from "@/services/seo/rate-limiter";

function textResponse(status: number, body: string, ok = status >= 200 && status < 300) {
  return { status, ok, text: async () => body, headers: { get: () => null } } as unknown as Response;
}

const HTML_PAGE = `<html><head><title>Empresa X - Serviços em Brasília</title>
<meta name="description" content="Descrição adequada com tamanho razoável para os padrões de SEO on-page.">
</head><body><h1>Empresa X</h1>${"palavra ".repeat(40)}</body></html>`;

beforeEach(() => {
  safeFetchMock.mockReset();
  resetSeoRateLimits();
});

describe("SeoCrawlerService.auditWebsite", () => {
  it("lança NO_PAGES_CRAWLED quando nenhuma página consegue ser carregada", async () => {
    safeFetchMock.mockRejectedValue(new Error("network error"));
    const { seoCrawlerService } = await import("@/services/seo/crawler");
    await expect(seoCrawlerService.auditWebsite("https://exemplo.com.br")).rejects.toMatchObject({
      code: "NO_PAGES_CRAWLED",
    });
  });

  it("audita a home quando não há robots.txt nem sitemap, com o issue correspondente", async () => {
    safeFetchMock.mockImplementation(async (url: string, init: { method?: string }) => {
      if (url.includes("robots.txt")) return textResponse(404, "");
      if (url.includes("sitemap.xml")) return textResponse(404, "");
      if (init?.method === "HEAD") return textResponse(200, "");
      return textResponse(200, HTML_PAGE);
    });

    const { seoCrawlerService } = await import("@/services/seo/crawler");
    const result = await seoCrawlerService.auditWebsite("https://exemplo.com.br");

    expect(result.pages).toHaveLength(1);
    expect(result.hasRobotsTxt).toBe(false);
    expect(result.hasSitemap).toBe(false);
    expect(result.issues.some((i) => i.type === "missing_robots_txt")).toBe(true);
    expect(result.issues.some((i) => i.type === "missing_sitemap")).toBe(true);
    expect(typeof result.seoScore).toBe("number");
  });

  it("segue o sitemap.xml declarado no robots.txt e audita as páginas listadas", async () => {
    const robotsTxt = "User-agent: *\nDisallow:\nSitemap: https://exemplo.com.br/sitemap.xml\n";
    const sitemapXml =
      "<urlset><url><loc>https://exemplo.com.br/</loc></url><url><loc>https://exemplo.com.br/servicos</loc></url></urlset>";

    safeFetchMock.mockImplementation(async (url: string, init: { method?: string }) => {
      if (url.includes("robots.txt")) return textResponse(200, robotsTxt);
      if (url.includes("sitemap.xml")) return textResponse(200, sitemapXml);
      if (init?.method === "HEAD") return textResponse(200, "");
      return textResponse(200, HTML_PAGE);
    });

    const { seoCrawlerService } = await import("@/services/seo/crawler");
    const result = await seoCrawlerService.auditWebsite("https://exemplo.com.br");

    expect(result.hasRobotsTxt).toBe(true);
    expect(result.hasSitemap).toBe(true);
    expect(result.pages.map((p) => p.url).sort()).toEqual(
      ["https://exemplo.com.br/", "https://exemplo.com.br/servicos"].sort()
    );
  });

  it("não audita paths bloqueados pelo robots.txt", async () => {
    const robotsTxt = "User-agent: *\nDisallow: /privado\nSitemap: https://exemplo.com.br/sitemap.xml\n";
    const sitemapXml =
      "<urlset><url><loc>https://exemplo.com.br/</loc></url><url><loc>https://exemplo.com.br/privado</loc></url></urlset>";

    safeFetchMock.mockImplementation(async (url: string, init: { method?: string }) => {
      if (url.includes("robots.txt")) return textResponse(200, robotsTxt);
      if (url.includes("sitemap.xml")) return textResponse(200, sitemapXml);
      if (init?.method === "HEAD") return textResponse(200, "");
      return textResponse(200, HTML_PAGE);
    });

    const { seoCrawlerService } = await import("@/services/seo/crawler");
    const result = await seoCrawlerService.auditWebsite("https://exemplo.com.br");

    expect(result.pages.map((p) => p.url)).toEqual(["https://exemplo.com.br/"]);
  });

  it("identifica links internos quebrados", async () => {
    const htmlComLink = `<html><head><title>Empresa X - página inicial de teste</title>
      <meta name="description" content="Descrição adequada com tamanho razoável para os padrões de SEO.">
      </head><body><h1>Empresa X</h1><a href="/pagina-removida">Link</a>${"palavra ".repeat(40)}</body></html>`;

    safeFetchMock.mockImplementation(async (url: string, init: { method?: string }) => {
      if (url.includes("robots.txt")) return textResponse(404, "");
      if (url.includes("sitemap.xml")) return textResponse(404, "");
      if (init?.method === "HEAD") return textResponse(404, "");
      return textResponse(200, htmlComLink);
    });

    const { seoCrawlerService } = await import("@/services/seo/crawler");
    const result = await seoCrawlerService.auditWebsite("https://exemplo.com.br");

    expect(result.issues.some((i) => i.type === "broken_internal_link")).toBe(true);
  });

  it("propaga o código de erro quando a URL é inválida, sem tentar buscar nada", async () => {
    const { seoCrawlerService } = await import("@/services/seo/crawler");
    await expect(seoCrawlerService.auditWebsite("   ")).rejects.toMatchObject({ code: "INVALID_URL" });
    expect(safeFetchMock).not.toHaveBeenCalled();
  });
});
