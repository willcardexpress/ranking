import { describe, expect, it } from "vitest";
import { parseRobotsTxt, isPathAllowed } from "@/services/seo/robots";

describe("parseRobotsTxt", () => {
  it("extrai Disallow do bloco User-agent: *", () => {
    const rules = parseRobotsTxt(`User-agent: *\nDisallow: /admin\nDisallow: /carrinho\n`);
    expect(rules.disallowedPaths).toEqual(["/admin", "/carrinho"]);
  });

  it("ignora blocos de user-agents específicos (não *)", () => {
    const rules = parseRobotsTxt(`User-agent: Googlebot\nDisallow: /so-google\n\nUser-agent: *\nDisallow: /geral\n`);
    expect(rules.disallowedPaths).toEqual(["/geral"]);
  });

  it("extrai declarações de Sitemap em qualquer posição do arquivo", () => {
    const rules = parseRobotsTxt(`Sitemap: https://exemplo.com/sitemap.xml\nUser-agent: *\nDisallow:\n`);
    expect(rules.sitemapUrls).toEqual(["https://exemplo.com/sitemap.xml"]);
  });

  it("ignora comentários e linhas vazias", () => {
    const rules = parseRobotsTxt(`# comentário\n\nUser-agent: *\n# outro comentário\nDisallow: /x\n`);
    expect(rules.disallowedPaths).toEqual(["/x"]);
  });

  it("trata arquivo sem nenhum User-agent como 'permite tudo'", () => {
    const rules = parseRobotsTxt(`Sitemap: https://exemplo.com/sitemap.xml\n`);
    expect(rules.disallowedPaths).toEqual([]);
  });
});

describe("isPathAllowed", () => {
  it("bloqueia paths com prefixo em disallowedPaths", () => {
    const rules = { disallowedPaths: ["/admin"], sitemapUrls: [] };
    expect(isPathAllowed(rules, "/admin/painel")).toBe(false);
  });

  it("permite paths fora das regras de bloqueio", () => {
    const rules = { disallowedPaths: ["/admin"], sitemapUrls: [] };
    expect(isPathAllowed(rules, "/sobre")).toBe(true);
  });

  it("permite tudo quando não há regras", () => {
    const rules = { disallowedPaths: [], sitemapUrls: [] };
    expect(isPathAllowed(rules, "/qualquer-coisa")).toBe(true);
  });
});
