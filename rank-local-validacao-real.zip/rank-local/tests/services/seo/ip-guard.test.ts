import { describe, expect, it } from "vitest";
import { isIPv4PrivateOrReserved, isIPv6PrivateOrReserved, isBlockedIp, isAllowedProtocol } from "@/services/seo/ip-guard";

describe("isIPv4PrivateOrReserved", () => {
  it("bloqueia loopback (127.0.0.0/8)", () => {
    expect(isIPv4PrivateOrReserved("127.0.0.1")).toBe(true);
    expect(isIPv4PrivateOrReserved("127.255.255.255")).toBe(true);
  });

  it("bloqueia ranges privados RFC 1918", () => {
    expect(isIPv4PrivateOrReserved("10.0.0.1")).toBe(true);
    expect(isIPv4PrivateOrReserved("10.255.255.255")).toBe(true);
    expect(isIPv4PrivateOrReserved("172.16.0.1")).toBe(true);
    expect(isIPv4PrivateOrReserved("172.31.255.255")).toBe(true);
    expect(isIPv4PrivateOrReserved("192.168.0.1")).toBe(true);
    expect(isIPv4PrivateOrReserved("192.168.255.255")).toBe(true);
  });

  it("bloqueia link-local, incluindo o metadata de nuvem 169.254.169.254", () => {
    expect(isIPv4PrivateOrReserved("169.254.169.254")).toBe(true);
    expect(isIPv4PrivateOrReserved("169.254.0.1")).toBe(true);
  });

  it("bloqueia CGNAT, TEST-NET, multicast e reservado", () => {
    expect(isIPv4PrivateOrReserved("100.64.0.1")).toBe(true);
    expect(isIPv4PrivateOrReserved("192.0.2.1")).toBe(true);
    expect(isIPv4PrivateOrReserved("198.51.100.1")).toBe(true);
    expect(isIPv4PrivateOrReserved("203.0.113.1")).toBe(true);
    expect(isIPv4PrivateOrReserved("224.0.0.1")).toBe(true);
    expect(isIPv4PrivateOrReserved("255.255.255.255")).toBe(true);
  });

  it("NÃO bloqueia IPs públicos válidos", () => {
    expect(isIPv4PrivateOrReserved("8.8.8.8")).toBe(false);
    expect(isIPv4PrivateOrReserved("1.1.1.1")).toBe(false);
    expect(isIPv4PrivateOrReserved("93.184.216.34")).toBe(false); // example.com (histórico)
  });

  it("trata entrada não parseável como bloqueada (falha segura)", () => {
    expect(isIPv4PrivateOrReserved("not-an-ip")).toBe(true);
    expect(isIPv4PrivateOrReserved("999.999.999.999")).toBe(true);
  });
});

describe("isIPv6PrivateOrReserved", () => {
  it("bloqueia loopback ::1", () => {
    expect(isIPv6PrivateOrReserved("::1")).toBe(true);
  });

  it("bloqueia unspecified ::", () => {
    expect(isIPv6PrivateOrReserved("::")).toBe(true);
  });

  it("bloqueia unique local (fc00::/7) e link-local (fe80::/10)", () => {
    expect(isIPv6PrivateOrReserved("fc00::1")).toBe(true);
    expect(isIPv6PrivateOrReserved("fd12:3456:789a::1")).toBe(true);
    expect(isIPv6PrivateOrReserved("fe80::1")).toBe(true);
    expect(isIPv6PrivateOrReserved("fe80::1234:5678:9abc:def0")).toBe(true);
  });

  it("bloqueia multicast (ff00::/8)", () => {
    expect(isIPv6PrivateOrReserved("ff02::1")).toBe(true);
  });

  it("bloqueia endereços IPv4-mapped que embutem um IP privado", () => {
    expect(isIPv6PrivateOrReserved("::ffff:127.0.0.1")).toBe(true);
    expect(isIPv6PrivateOrReserved("::ffff:169.254.169.254")).toBe(true);
    expect(isIPv6PrivateOrReserved("::ffff:10.0.0.1")).toBe(true);
  });

  it("NÃO bloqueia endereços IPv4-mapped que embutem um IP público", () => {
    expect(isIPv6PrivateOrReserved("::ffff:8.8.8.8")).toBe(false);
  });

  it("NÃO bloqueia IPv6 público válido", () => {
    expect(isIPv6PrivateOrReserved("2606:4700:4700::1111")).toBe(false); // Cloudflare DNS
  });

  it("trata entrada não parseável como bloqueada (falha segura)", () => {
    expect(isIPv6PrivateOrReserved("not-an-ipv6")).toBe(true);
  });
});

describe("isBlockedIp (dispatcher v4/v6)", () => {
  it("localhost/127.0.0.1", () => {
    expect(isBlockedIp("127.0.0.1")).toBe(true);
  });
  it("10.x", () => {
    expect(isBlockedIp("10.1.2.3")).toBe(true);
  });
  it("172.16.x", () => {
    expect(isBlockedIp("172.16.5.5")).toBe(true);
  });
  it("192.168.x", () => {
    expect(isBlockedIp("192.168.1.1")).toBe(true);
  });
  it("169.254.169.254 (metadata de nuvem)", () => {
    expect(isBlockedIp("169.254.169.254")).toBe(true);
  });
  it("IPv6 local (::1)", () => {
    expect(isBlockedIp("::1")).toBe(true);
  });
  it("domínio público válido (IP)", () => {
    expect(isBlockedIp("8.8.8.8")).toBe(false);
  });
  it("string que não é IP nenhum é bloqueada", () => {
    expect(isBlockedIp("exemplo.com")).toBe(true);
  });
});

describe("isAllowedProtocol", () => {
  it("permite http e https", () => {
    expect(isAllowedProtocol("http:")).toBe(true);
    expect(isAllowedProtocol("https:")).toBe(true);
  });

  it("bloqueia outros protocolos (file, ftp, gopher, data...)", () => {
    expect(isAllowedProtocol("file:")).toBe(false);
    expect(isAllowedProtocol("ftp:")).toBe(false);
    expect(isAllowedProtocol("gopher:")).toBe(false);
    expect(isAllowedProtocol("data:")).toBe(false);
  });
});
