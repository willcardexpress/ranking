import { describe, expect, it } from "vitest";
import { parseHtml } from "@/services/seo/parser";

const BASE_URL = "https://exemplo.com.br/pagina";

function html(body: string) {
  return `<html><head>${body}</head><body>Conteúdo de teste com bastante texto para não cair em thin content. ${"palavra ".repeat(
    40
  )}</body></html>`;
}

describe("parseHtml", () => {
  it("extrai title e o marca como https quando a URL usa https", () => {
    const signals = parseHtml(BASE_URL, 200, html("<title>Minha Empresa - Serviços em Brasília</title>"));
    expect(signals.title).toBe("Minha Empresa - Serviços em Brasília");
    expect(signals.isHttps).toBe(true);
  });

  it("detecta ausência de title", () => {
    const signals = parseHtml(BASE_URL, 200, html(""));
    expect(signals.title).toBeNull();
    expect(signals.titleLength).toBe(0);
  });

  it("extrai meta description", () => {
    const signals = parseHtml(BASE_URL, 200, html('<meta name="description" content="Descrição da página aqui.">'));
    expect(signals.metaDescription).toBe("Descrição da página aqui.");
  });

  it("conta H1 e H2 corretamente", () => {
    const signals = parseHtml(
      BASE_URL,
      200,
      `<html><head></head><body><h1>Título 1</h1><h1>Título 2</h1><h2>Sub</h2>${"palavra ".repeat(
        40
      )}</body></html>`
    );
    expect(signals.h1Count).toBe(2);
    expect(signals.h2Count).toBe(1);
  });

  it("detecta canonical, schema (JSON-LD) e Open Graph", () => {
    const signals = parseHtml(
      BASE_URL,
      200,
      html(
        '<link rel="canonical" href="https://exemplo.com.br/pagina">' +
          '<script type="application/ld+json">{}</script>' +
          '<meta property="og:title" content="X">'
      )
    );
    expect(signals.canonical).toBe("https://exemplo.com.br/pagina");
    expect(signals.hasSchema).toBe(true);
    expect(signals.hasOpenGraph).toBe(true);
  });

  it("conta imagens sem atributo alt", () => {
    const signals = parseHtml(
      BASE_URL,
      200,
      `<html><head></head><body><img src="a.jpg" alt="ok"><img src="b.jpg"><img src="c.jpg" alt="">${"palavra ".repeat(
        40
      )}</body></html>`
    );
    expect(signals.imagesTotal).toBe(3);
    expect(signals.imagesWithoutAlt).toBe(2);
  });

  it("coleta apenas links internos (mesmo domínio), ignorando âncoras e mailto", () => {
    const signals = parseHtml(
      BASE_URL,
      200,
      `<html><head></head><body>
        <a href="/sobre">Sobre</a>
        <a href="https://exemplo.com.br/contato">Contato</a>
        <a href="https://outrosite.com/x">Externo</a>
        <a href="#topo">Âncora</a>
        <a href="mailto:a@a.com">Email</a>
        ${"palavra ".repeat(40)}
      </body></html>`
    );
    expect(signals.internalLinks).toContain("https://exemplo.com.br/sobre");
    expect(signals.internalLinks).toContain("https://exemplo.com.br/contato");
    expect(signals.internalLinks.some((l) => l.includes("outrosite"))).toBe(false);
    expect(signals.internalLinks.length).toBe(2);
  });

  it("detecta a presença de meta viewport", () => {
    const withViewport = parseHtml(BASE_URL, 200, html('<meta name="viewport" content="width=device-width">'));
    const withoutViewport = parseHtml(BASE_URL, 200, html(""));
    expect(withViewport.hasViewportMeta).toBe(true);
    expect(withoutViewport.hasViewportMeta).toBe(false);
  });
});
