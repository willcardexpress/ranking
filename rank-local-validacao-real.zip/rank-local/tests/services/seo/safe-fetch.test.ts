import { describe, expect, it, vi, beforeEach } from "vitest";

vi.mock("server-only", () => ({}));

const lookupMock = vi.fn();
vi.mock("node:dns/promises", () => {
  const mod = { lookup: (...args: unknown[]) => lookupMock(...args) };
  return { ...mod, default: mod };
});

const undiciFetchMock = vi.fn();
vi.mock("undici", () => ({
  Agent: class FakeAgent {
    async close() {
      /* no-op */
    }
  },
  fetch: (...args: unknown[]) => undiciFetchMock(...args),
}));

function fakeResponse(status: number, headers: Record<string, string> = {}) {
  const map = new Map(Object.entries(headers).map(([k, v]) => [k.toLowerCase(), v]));
  return {
    status,
    ok: status >= 200 && status < 300,
    headers: { get: (name: string) => map.get(name.toLowerCase()) ?? null },
    text: async () => "",
  };
}

// Importado depois dos mocks acima, para que "server-only"/"node:dns/promises"/"undici" já estejam substituídos.
const { safeFetch } = await import("@/services/seo/safe-fetch");
const { SeoServiceError } = await import("@/services/seo/errors");

beforeEach(() => {
  lookupMock.mockReset();
  undiciFetchMock.mockReset();
});

describe("safeFetch — bloqueio de SSRF por IP resolvido", () => {
  it("bloqueia localhost", async () => {
    lookupMock.mockResolvedValue({ address: "127.0.0.1", family: 4 });
    await expect(safeFetch("http://localhost/")).rejects.toMatchObject({ code: "SSRF_BLOCKED" });
    expect(undiciFetchMock).not.toHaveBeenCalled();
  });

  it("bloqueia 127.0.0.1 direto na URL", async () => {
    lookupMock.mockResolvedValue({ address: "127.0.0.1", family: 4 });
    await expect(safeFetch("http://127.0.0.1/admin")).rejects.toMatchObject({ code: "SSRF_BLOCKED" });
  });

  it("bloqueia range 10.x", async () => {
    lookupMock.mockResolvedValue({ address: "10.0.0.5", family: 4 });
    await expect(safeFetch("http://intranet.exemplo/")).rejects.toMatchObject({ code: "SSRF_BLOCKED" });
  });

  it("bloqueia range 172.16.x", async () => {
    lookupMock.mockResolvedValue({ address: "172.16.1.1", family: 4 });
    await expect(safeFetch("http://interno.exemplo/")).rejects.toMatchObject({ code: "SSRF_BLOCKED" });
  });

  it("bloqueia range 192.168.x", async () => {
    lookupMock.mockResolvedValue({ address: "192.168.0.10", family: 4 });
    await expect(safeFetch("http://roteador.exemplo/")).rejects.toMatchObject({ code: "SSRF_BLOCKED" });
  });

  it("bloqueia 169.254.169.254 (metadata de nuvem)", async () => {
    lookupMock.mockResolvedValue({ address: "169.254.169.254", family: 4 });
    await expect(safeFetch("http://metadata.google.internal/")).rejects.toMatchObject({ code: "SSRF_BLOCKED" });
  });

  it("bloqueia IPv6 local (::1)", async () => {
    lookupMock.mockResolvedValue({ address: "::1", family: 6 });
    await expect(safeFetch("http://ipv6-local.exemplo/")).rejects.toMatchObject({ code: "SSRF_BLOCKED" });
  });

  it("bloqueia quando o DNS não resolve o host", async () => {
    lookupMock.mockRejectedValue(new Error("ENOTFOUND"));
    await expect(safeFetch("http://nao-existe.invalido/")).rejects.toMatchObject({ code: "SSRF_BLOCKED" });
  });

  it("bloqueia protocolos que não sejam http/https", async () => {
    await expect(safeFetch("file:///etc/passwd")).rejects.toMatchObject({ code: "SSRF_BLOCKED" });
    expect(lookupMock).not.toHaveBeenCalled();
  });

  it("rejeita URL inválida sem tentar resolver DNS", async () => {
    await expect(safeFetch("não é uma url")).rejects.toMatchObject({ code: "INVALID_URL" });
    expect(lookupMock).not.toHaveBeenCalled();
  });
});

describe("safeFetch — domínio público válido", () => {
  it("completa a requisição normalmente quando o host resolve para IP público", async () => {
    lookupMock.mockResolvedValue({ address: "8.8.8.8", family: 4 });
    undiciFetchMock.mockResolvedValue(fakeResponse(200));

    const response = await safeFetch("https://exemplo-publico.com.br/");
    expect(response.status).toBe(200);
    expect(undiciFetchMock).toHaveBeenCalledTimes(1);
  });
});

describe("safeFetch — redirects revalidados a cada salto", () => {
  it("bloqueia quando um redirect aponta para um IP privado (proteção contra DNS rebinding)", async () => {
    lookupMock.mockImplementation(async (hostname: string) => {
      if (hostname === "publico.exemplo.com") return { address: "8.8.8.8", family: 4 };
      if (hostname === "interno.exemplo.com") return { address: "10.0.0.1", family: 4 };
      throw new Error("host inesperado no teste");
    });
    undiciFetchMock.mockResolvedValueOnce(
      fakeResponse(302, { location: "http://interno.exemplo.com/secreto" })
    );

    await expect(safeFetch("https://publico.exemplo.com/")).rejects.toMatchObject({ code: "SSRF_BLOCKED" });
    // só a primeira requisição (para o host público) deve ter sido feita
    expect(undiciFetchMock).toHaveBeenCalledTimes(1);
  });

  it("segue um redirect entre dois hosts públicos normalmente", async () => {
    lookupMock.mockImplementation(async (hostname: string) => {
      if (hostname === "a.exemplo.com") return { address: "8.8.8.8", family: 4 };
      if (hostname === "b.exemplo.com") return { address: "1.1.1.1", family: 4 };
      throw new Error("host inesperado no teste");
    });
    undiciFetchMock
      .mockResolvedValueOnce(fakeResponse(301, { location: "https://b.exemplo.com/destino" }))
      .mockResolvedValueOnce(fakeResponse(200));

    const response = await safeFetch("https://a.exemplo.com/origem");
    expect(response.status).toBe(200);
    expect(undiciFetchMock).toHaveBeenCalledTimes(2);
  });

  it("interrompe após o limite de redirects", async () => {
    lookupMock.mockResolvedValue({ address: "8.8.8.8", family: 4 });
    undiciFetchMock.mockImplementation(async (url: string) => fakeResponse(302, { location: `${url}x` }));

    await expect(safeFetch("https://loop.exemplo.com/")).rejects.toMatchObject({ code: "TOO_MANY_REDIRECTS" });
  });
});

describe("SeoServiceError exportado por safe-fetch", () => {
  it("é a mesma classe de services/seo/errors", async () => {
    lookupMock.mockResolvedValue({ address: "127.0.0.1", family: 4 });
    try {
      await safeFetch("http://localhost/");
      expect.unreachable();
    } catch (error) {
      expect(error).toBeInstanceOf(SeoServiceError);
    }
  });
});
