import { describe, expect, it } from "vitest";
import { evaluatePageIssues, evaluateSiteIssues } from "@/services/seo/rules";
import type { PageSignals } from "@/services/seo/parser";

function baseSignals(overrides: Partial<PageSignals> = {}): PageSignals {
  return {
    url: "https://exemplo.com.br/",
    statusCode: 200,
    isHttps: true,
    title: "Título ideal com tamanho adequado para SEO",
    titleLength: 45,
    metaDescription: "Uma meta description com tamanho adequado para os padrões recomendados de SEO on-page.",
    metaDescriptionLength: 90,
    h1Count: 1,
    h1Texts: ["Título"],
    h2Count: 2,
    canonical: "https://exemplo.com.br/",
    hasSchema: true,
    hasOpenGraph: true,
    imagesTotal: 3,
    imagesWithoutAlt: 0,
    internalLinks: [],
    wordCount: 400,
    hasViewportMeta: true,
    ...overrides,
  };
}

describe("evaluatePageIssues", () => {
  it("não gera nenhum problema para uma página bem otimizada", () => {
    expect(evaluatePageIssues(baseSignals())).toEqual([]);
  });

  it("detecta ausência de HTTPS como crítico", () => {
    const issues = evaluatePageIssues(baseSignals({ isHttps: false, url: "http://exemplo.com.br/" }));
    expect(issues.some((i) => i.type === "no_https" && i.severity === "critical")).toBe(true);
  });

  it("detecta status de erro como crítico", () => {
    const issues = evaluatePageIssues(baseSignals({ statusCode: 404 }));
    expect(issues.some((i) => i.type === "page_error_status" && i.severity === "critical")).toBe(true);
  });

  it("detecta title ausente e title fora da faixa ideal", () => {
    const missing = evaluatePageIssues(baseSignals({ title: null, titleLength: 0 }));
    expect(missing.some((i) => i.type === "missing_title")).toBe(true);

    const tooShort = evaluatePageIssues(baseSignals({ title: "Curto", titleLength: 5 }));
    expect(tooShort.some((i) => i.type === "title_length")).toBe(true);
  });

  it("detecta meta description ausente", () => {
    const issues = evaluatePageIssues(baseSignals({ metaDescription: null, metaDescriptionLength: 0 }));
    expect(issues.some((i) => i.type === "missing_meta_description")).toBe(true);
  });

  it("detecta H1 ausente e múltiplos H1", () => {
    const missing = evaluatePageIssues(baseSignals({ h1Count: 0 }));
    expect(missing.some((i) => i.type === "missing_h1")).toBe(true);

    const multiple = evaluatePageIssues(baseSignals({ h1Count: 3 }));
    expect(multiple.some((i) => i.type === "multiple_h1")).toBe(true);
  });

  it("detecta imagens sem ALT", () => {
    const issues = evaluatePageIssues(baseSignals({ imagesTotal: 5, imagesWithoutAlt: 2 }));
    expect(issues.some((i) => i.type === "images_without_alt")).toBe(true);
  });

  it("detecta conteúdo raso (thin content)", () => {
    const issues = evaluatePageIssues(baseSignals({ wordCount: 50 }));
    expect(issues.some((i) => i.type === "thin_content")).toBe(true);
  });

  it("todo problema de página carrega a URL da página", () => {
    const issues = evaluatePageIssues(baseSignals({ title: null, titleLength: 0 }));
    expect(issues.every((i) => i.pageUrl === "https://exemplo.com.br/")).toBe(true);
  });
});

describe("evaluateSiteIssues", () => {
  it("detecta ausência de robots.txt e sitemap", () => {
    const issues = evaluateSiteIssues({ hasRobotsTxt: false, hasSitemap: false, brokenLinks: [] });
    expect(issues.some((i) => i.type === "missing_robots_txt")).toBe(true);
    expect(issues.some((i) => i.type === "missing_sitemap")).toBe(true);
  });

  it("não gera problemas de site quando tudo está presente e sem links quebrados", () => {
    const issues = evaluateSiteIssues({ hasRobotsTxt: true, hasSitemap: true, brokenLinks: [] });
    expect(issues).toEqual([]);
  });

  it("gera um problema por link interno quebrado", () => {
    const issues = evaluateSiteIssues({
      hasRobotsTxt: true,
      hasSitemap: true,
      brokenLinks: [
        { url: "https://exemplo.com.br/antigo", status: 404 },
        { url: "https://exemplo.com.br/removido", status: null },
      ],
    });
    expect(issues.filter((i) => i.type === "broken_internal_link")).toHaveLength(2);
  });
});
