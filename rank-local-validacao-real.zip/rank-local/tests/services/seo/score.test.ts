import { describe, expect, it } from "vitest";
import { computeSeoScore } from "@/services/seo/score";

describe("computeSeoScore", () => {
  it("retorna 100 quando não há problemas", () => {
    expect(computeSeoScore([])).toBe(100);
  });

  it("desconta mais por problemas críticos do que por avisos ou informativos", () => {
    const criticalScore = computeSeoScore([{ severity: "critical" }]);
    const warningScore = computeSeoScore([{ severity: "warning" }]);
    const infoScore = computeSeoScore([{ severity: "info" }]);
    expect(criticalScore).toBeLessThan(warningScore);
    expect(warningScore).toBeLessThan(infoScore);
  });

  it("nunca fica abaixo de 0 mesmo com muitos problemas críticos", () => {
    const manyCritical = Array.from({ length: 50 }, () => ({ severity: "critical" as const }));
    expect(computeSeoScore(manyCritical)).toBe(0);
  });

  it("nunca ultrapassa 100", () => {
    expect(computeSeoScore([])).toBeLessThanOrEqual(100);
  });
});
