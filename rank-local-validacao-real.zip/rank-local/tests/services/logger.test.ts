import { describe, expect, it, vi, beforeEach, afterEach } from "vitest";
import { createScopedLogger } from "@/services/google/logger";

describe("logger seguro", () => {
  let consoleLogSpy: ReturnType<typeof vi.spyOn>;

  beforeEach(() => {
    consoleLogSpy = vi.spyOn(console, "log").mockImplementation(() => {});
  });

  afterEach(() => {
    consoleLogSpy.mockRestore();
  });

  it("nunca inclui campos chamados apiKey/token/secret em texto plano", () => {
    const logger = createScopedLogger("test.scope");
    logger.info("chamada realizada", {
      apiKey: "AIzaSy-super-secreta",
      accessToken: "ghp_super-secreto",
      queryLength: 12,
    });

    const loggedLine = consoleLogSpy.mock.calls[0][0] as string;
    expect(loggedLine).not.toContain("AIzaSy-super-secreta");
    expect(loggedLine).not.toContain("ghp_super-secreto");

    const parsed = JSON.parse(loggedLine);
    expect(parsed.apiKey).toBe("[REDACTED]");
    expect(parsed.accessToken).toBe("[REDACTED]");
    expect(parsed.queryLength).toBe(12);
  });

  it("mantém campos não sensíveis intactos e inclui o escopo/mensagem", () => {
    const logger = createScopedLogger("google.places");
    logger.info("search completed", { resultCount: 5 });

    const parsed = JSON.parse(consoleLogSpy.mock.calls[0][0] as string);
    expect(parsed.scope).toBe("google.places");
    expect(parsed.message).toBe("search completed");
    expect(parsed.resultCount).toBe(5);
    expect(parsed.level).toBe("info");
    expect(typeof parsed.timestamp).toBe("string");
  });
});
