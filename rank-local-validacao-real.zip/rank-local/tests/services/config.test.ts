import { describe, expect, it, beforeEach, afterEach } from "vitest";
import { isGooglePlacesConfigured, isGoogleBusinessProfileConfigured } from "@/services/google/config";

describe("isGooglePlacesConfigured", () => {
  const original = process.env.GOOGLE_PLACES_API_KEY;

  beforeEach(() => {
    delete process.env.GOOGLE_PLACES_API_KEY;
  });

  afterEach(() => {
    if (original === undefined) {
      delete process.env.GOOGLE_PLACES_API_KEY;
    } else {
      process.env.GOOGLE_PLACES_API_KEY = original;
    }
  });

  it("retorna false quando a variável não está definida", () => {
    expect(isGooglePlacesConfigured()).toBe(false);
  });

  it("retorna false quando a variável está vazia ou só espaços", () => {
    process.env.GOOGLE_PLACES_API_KEY = "   ";
    expect(isGooglePlacesConfigured()).toBe(false);
  });

  it("retorna true quando a variável está definida com um valor", () => {
    process.env.GOOGLE_PLACES_API_KEY = "AIzaSy-fake-key-for-tests";
    expect(isGooglePlacesConfigured()).toBe(true);
  });
});

describe("isGoogleBusinessProfileConfigured", () => {
  const GBP_VARS = ["GOOGLE_CLIENT_ID", "GOOGLE_CLIENT_SECRET", "GOOGLE_OAUTH_REDIRECT_URI", "GBP_OAUTH_STATE_SECRET"] as const;
  const originalValues = Object.fromEntries(GBP_VARS.map((k) => [k, process.env[k]]));

  beforeEach(() => {
    for (const key of GBP_VARS) delete process.env[key];
  });

  afterEach(() => {
    for (const key of GBP_VARS) {
      const original = originalValues[key];
      if (original === undefined) delete process.env[key];
      else process.env[key] = original;
    }
  });

  it("retorna false quando nenhuma variável está definida", () => {
    expect(isGoogleBusinessProfileConfigured()).toBe(false);
  });

  it("retorna false quando falta só o GBP_OAUTH_STATE_SECRET", () => {
    process.env.GOOGLE_CLIENT_ID = "id";
    process.env.GOOGLE_CLIENT_SECRET = "secret";
    process.env.GOOGLE_OAUTH_REDIRECT_URI = "https://app.exemplo.com/callback";
    expect(isGoogleBusinessProfileConfigured()).toBe(false);
  });

  it("retorna true quando todas as quatro variáveis estão definidas", () => {
    process.env.GOOGLE_CLIENT_ID = "id";
    process.env.GOOGLE_CLIENT_SECRET = "secret";
    process.env.GOOGLE_OAUTH_REDIRECT_URI = "https://app.exemplo.com/callback";
    process.env.GBP_OAUTH_STATE_SECRET = "um-segredo-bem-aleatorio";
    expect(isGoogleBusinessProfileConfigured()).toBe(true);
  });
});
