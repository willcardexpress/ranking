import { describe, expect, it, vi, beforeEach, afterEach } from "vitest";

vi.mock("server-only", () => ({}));

import { clearCache } from "@/services/google/cache";
import { resetRateLimits } from "@/services/google/rate-limiter";

const ORIGINAL_ENV = {
  GOOGLE_CLIENT_ID: process.env.GOOGLE_CLIENT_ID,
  GOOGLE_CLIENT_SECRET: process.env.GOOGLE_CLIENT_SECRET,
  GOOGLE_OAUTH_REDIRECT_URI: process.env.GOOGLE_OAUTH_REDIRECT_URI,
};

function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status });
}

beforeEach(() => {
  clearCache();
  resetRateLimits();
  vi.restoreAllMocks();
  process.env.GOOGLE_CLIENT_ID = "client-id";
  process.env.GOOGLE_CLIENT_SECRET = "client-secret";
  process.env.GOOGLE_OAUTH_REDIRECT_URI = "https://app.exemplo.com/api/integrations/google-business/callback";
});

afterEach(() => {
  process.env.GOOGLE_CLIENT_ID = ORIGINAL_ENV.GOOGLE_CLIENT_ID;
  process.env.GOOGLE_CLIENT_SECRET = ORIGINAL_ENV.GOOGLE_CLIENT_SECRET;
  process.env.GOOGLE_OAUTH_REDIRECT_URI = ORIGINAL_ENV.GOOGLE_OAUTH_REDIRECT_URI;
});

describe("GoogleBusinessProfileService.buildAuthUrl", () => {
  it("lança MISSING_OAUTH_CONFIG quando faltam variáveis de ambiente", async () => {
    delete process.env.GOOGLE_CLIENT_ID;
    const { GoogleBusinessProfileService } = await import("@/services/google/business-profile");
    const service = new GoogleBusinessProfileService();
    expect(() => service.buildAuthUrl("state-qualquer")).toThrow(
      expect.objectContaining({ code: "MISSING_OAUTH_CONFIG" })
    );
  });

  it("monta a URL de autorização com escopo e state corretos", async () => {
    const { GoogleBusinessProfileService } = await import("@/services/google/business-profile");
    const service = new GoogleBusinessProfileService();
    const url = new URL(service.buildAuthUrl("meu-state-assinado"));

    expect(url.origin + url.pathname).toBe("https://accounts.google.com/o/oauth2/v2/auth");
    expect(url.searchParams.get("client_id")).toBe("client-id");
    expect(url.searchParams.get("scope")).toBe("https://www.googleapis.com/auth/business.manage");
    expect(url.searchParams.get("state")).toBe("meu-state-assinado");
    expect(url.searchParams.get("access_type")).toBe("offline");
  });
});

describe("GoogleBusinessProfileService.exchangeCodeForTokens", () => {
  it("retorna os tokens normalizados em caso de sucesso", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(
        jsonResponse({ access_token: "at-123", refresh_token: "rt-456", expires_in: 3600, scope: "business.manage" })
      )
    );
    const { GoogleBusinessProfileService } = await import("@/services/google/business-profile");
    const service = new GoogleBusinessProfileService();
    const tokens = await service.exchangeCodeForTokens("auth-code");

    expect(tokens.accessToken).toBe("at-123");
    expect(tokens.refreshToken).toBe("rt-456");
    expect(new Date(tokens.expiresAt).getTime()).toBeGreaterThan(Date.now());
  });

  it("lança TOKEN_EXCHANGE_FAILED quando a Google recusa o código", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response("", { status: 400 })));
    const { GoogleBusinessProfileService } = await import("@/services/google/business-profile");
    const service = new GoogleBusinessProfileService();
    await expect(service.exchangeCodeForTokens("code-invalido")).rejects.toMatchObject({
      code: "TOKEN_EXCHANGE_FAILED",
    });
  });
});

describe("GoogleBusinessProfileService.refreshAccessToken", () => {
  it("lança TOKEN_REVOKED em 400/401 (refresh_token inválido/revogado)", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response("", { status: 400 })));
    const { GoogleBusinessProfileService } = await import("@/services/google/business-profile");
    const service = new GoogleBusinessProfileService();
    await expect(service.refreshAccessToken("rt-revogado")).rejects.toMatchObject({ code: "TOKEN_REVOKED" });
  });

  it("renova o access token preservando o refresh_token original", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(jsonResponse({ access_token: "at-novo", expires_in: 3600, scope: "business.manage" }))
    );
    const { GoogleBusinessProfileService } = await import("@/services/google/business-profile");
    const service = new GoogleBusinessProfileService();
    const tokens = await service.refreshAccessToken("rt-original");
    expect(tokens.accessToken).toBe("at-novo");
    expect(tokens.refreshToken).toBe("rt-original");
  });
});

describe("GoogleBusinessProfileService.listAccounts", () => {
  it("lança TOKEN_EXPIRED em 401", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response("", { status: 401 })));
    const { GoogleBusinessProfileService } = await import("@/services/google/business-profile");
    const service = new GoogleBusinessProfileService();
    await expect(service.listAccounts("token-expirado")).rejects.toMatchObject({ code: "TOKEN_EXPIRED" });
  });

  it("lança PERMISSION_DENIED em 403 (Basic API Access não aprovado)", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response("", { status: 403 })));
    const { GoogleBusinessProfileService } = await import("@/services/google/business-profile");
    const service = new GoogleBusinessProfileService();
    await expect(service.listAccounts("token-valido")).rejects.toMatchObject({ code: "PERMISSION_DENIED" });
  });

  it("retorna as contas normalizadas em caso de sucesso", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(jsonResponse({ accounts: [{ name: "accounts/123", accountName: "Minha Agência" }] }))
    );
    const { GoogleBusinessProfileService } = await import("@/services/google/business-profile");
    const service = new GoogleBusinessProfileService();
    const accounts = await service.listAccounts("token-valido");
    expect(accounts).toEqual([{ resourceName: "accounts/123", accountName: "Minha Agência", type: null }]);
  });
});

describe("GoogleBusinessProfileService.listLocations", () => {
  it("inclui o readMask obrigatório na URL", async () => {
    const fetchMock = vi.fn().mockResolvedValue(jsonResponse({ locations: [] }));
    vi.stubGlobal("fetch", fetchMock);
    const { GoogleBusinessProfileService } = await import("@/services/google/business-profile");
    const service = new GoogleBusinessProfileService();
    await service.listLocations("token-valido", "accounts/123");

    const [url] = fetchMock.mock.calls[0];
    expect(url).toContain("accounts/123/locations");
    expect(url).toContain("readMask=");
    expect(decodeURIComponent(url)).toContain("title");
  });

  it("normaliza um local com endereço, categoria e metadata", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(
        jsonResponse({
          locations: [
            {
              name: "locations/456",
              title: "Auto Baterias Taguatinga",
              categories: { primaryCategory: { displayName: "Loja de baterias" } },
              storefrontAddress: { addressLines: ["QNM 1"], locality: "Taguatinga" },
              metadata: { placeId: "place-xyz", mapsUri: "https://maps.google.com/xyz" },
            },
          ],
        })
      )
    );
    const { GoogleBusinessProfileService } = await import("@/services/google/business-profile");
    const service = new GoogleBusinessProfileService();
    const [location] = await service.listLocations("token-valido", "accounts/123");

    expect(location.resourceName).toBe("locations/456");
    expect(location.primaryCategory).toBe("Loja de baterias");
    expect(location.placeId).toBe("place-xyz");
    expect(location.description).toBeNull(); // ausente na resposta => null, não inventado
  });
});

describe("GoogleBusinessProfileService.getLocation", () => {
  it("lança INVALID_REQUEST quando o local não está mais na lista da conta", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(jsonResponse({ locations: [] })));
    const { GoogleBusinessProfileService } = await import("@/services/google/business-profile");
    const service = new GoogleBusinessProfileService();
    await expect(service.getLocation("token", "accounts/123", "locations/999")).rejects.toMatchObject({
      code: "INVALID_REQUEST",
    });
  });
});
