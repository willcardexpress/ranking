import { describe, expect, it, vi, beforeEach, afterEach } from "vitest";

vi.mock("server-only", () => ({}));

import { clearCache } from "@/services/google/cache";
import { resetRateLimits } from "@/services/google/rate-limiter";
import { PlacesServiceError } from "@/services/google/errors";

const ORIGINAL_KEY = process.env.GOOGLE_PLACES_API_KEY;

function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status });
}

beforeEach(() => {
  clearCache();
  resetRateLimits();
  vi.restoreAllMocks();
  process.env.GOOGLE_PLACES_API_KEY = "test-key";
});

afterEach(() => {
  process.env.GOOGLE_PLACES_API_KEY = ORIGINAL_KEY;
});

describe("GooglePlacesService.searchText", () => {
  it("lança MISSING_API_KEY quando a variável de ambiente não está configurada", async () => {
    delete process.env.GOOGLE_PLACES_API_KEY;
    const { GooglePlacesService } = await import("@/services/google/places");
    const service = new GooglePlacesService();

    await expect(service.searchText("dentista em Brasília")).rejects.toMatchObject({ code: "MISSING_API_KEY" });
  });

  it("lança INVALID_REQUEST para queries muito curtas", async () => {
    const { GooglePlacesService } = await import("@/services/google/places");
    const service = new GooglePlacesService();
    await expect(service.searchText("ab")).rejects.toMatchObject({ code: "INVALID_REQUEST" });
  });

  it("normaliza o resultado da API em NormalizedPlace[]", async () => {
    const fetchMock = vi.fn().mockResolvedValue(
      jsonResponse({
        places: [
          {
            id: "place-123",
            displayName: { text: "Auto Baterias Taguatinga" },
            formattedAddress: "Taguatinga, DF",
            rating: 4.5,
            userRatingCount: 100,
          },
        ],
      })
    );
    vi.stubGlobal("fetch", fetchMock);

    const { GooglePlacesService } = await import("@/services/google/places");
    const service = new GooglePlacesService();
    const result = await service.searchText("troca de bateria em Taguatinga");

    expect(result.fromCache).toBe(false);
    expect(result.places).toHaveLength(1);
    expect(result.places[0].placeId).toBe("place-123");
    expect(result.places[0].displayName).toBe("Auto Baterias Taguatinga");
    // campo ausente na resposta vira null, nunca um valor inventado
    expect(result.places[0].website).toBeNull();

    // confere que a chamada usa o endpoint e o field mask corretos
    const [url, init] = fetchMock.mock.calls[0];
    expect(url).toBe("https://places.googleapis.com/v1/places:searchText");
    expect((init.headers as Record<string, string>)["X-Goog-Api-Key"]).toBe("test-key");
    expect((init.headers as Record<string, string>)["X-Goog-FieldMask"]).toContain("places.id");
  });

  it("usa o cache em buscas repetidas (não chama fetch de novo)", async () => {
    const fetchMock = vi.fn().mockResolvedValue(jsonResponse({ places: [] }));
    vi.stubGlobal("fetch", fetchMock);

    const { GooglePlacesService } = await import("@/services/google/places");
    const service = new GooglePlacesService();
    await service.searchText("mesma busca");
    const second = await service.searchText("mesma busca");

    expect(fetchMock).toHaveBeenCalledTimes(1);
    expect(second.fromCache).toBe(true);
  });

  it("mapeia HTTP 429 para RATE_LIMITED", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response("", { status: 429 })));
    const { GooglePlacesService } = await import("@/services/google/places");
    const service = new GooglePlacesService();
    await expect(service.searchText("busca qualquer")).rejects.toMatchObject({ code: "RATE_LIMITED" });
  });

  it("mapeia outros erros HTTP para UPSTREAM_ERROR", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response("", { status: 500 })));
    const { GooglePlacesService } = await import("@/services/google/places");
    const service = new GooglePlacesService();
    await expect(service.searchText("busca qualquer")).rejects.toMatchObject({ code: "UPSTREAM_ERROR" });
  });

  it("respeita o rate limit interno (30 buscas/min)", async () => {
    vi.stubGlobal("fetch", vi.fn().mockImplementation(() => Promise.resolve(jsonResponse({ places: [] }))));
    const { GooglePlacesService } = await import("@/services/google/places");
    const service = new GooglePlacesService();

    for (let i = 0; i < 30; i++) {
      await service.searchText(`busca numero ${i}`);
    }
    await expect(service.searchText("busca 31")).rejects.toMatchObject({ code: "INTERNAL_RATE_LIMITED" });
  });
});

describe("GooglePlacesService.getDetails", () => {
  it("lança INVALID_REQUEST sem placeId", async () => {
    const { GooglePlacesService } = await import("@/services/google/places");
    const service = new GooglePlacesService();
    await expect(service.getDetails("")).rejects.toMatchObject({ code: "INVALID_REQUEST" });
  });

  it("mapeia 404 para INVALID_REQUEST (place não encontrado)", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response("", { status: 404 })));
    const { GooglePlacesService } = await import("@/services/google/places");
    const service = new GooglePlacesService();
    await expect(service.getDetails("place-inexistente")).rejects.toMatchObject({ code: "INVALID_REQUEST" });
  });

  it("retorna o place normalizado em caso de sucesso", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(jsonResponse({ id: "place-1", displayName: { text: "Empresa X" } }))
    );
    const { GooglePlacesService } = await import("@/services/google/places");
    const service = new GooglePlacesService();
    const place = await service.getDetails("place-1");
    expect(place.placeId).toBe("place-1");
    expect(place.displayName).toBe("Empresa X");
  });
});

describe("GooglePlacesService.searchNearbyCompetitors", () => {
  it("exclui o placeId da própria empresa do resultado", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(
        jsonResponse({
          places: [
            { id: "place-self", displayName: { text: "Minha Empresa" } },
            { id: "place-competitor", displayName: { text: "Concorrente" } },
          ],
        })
      )
    );
    const { GooglePlacesService } = await import("@/services/google/places");
    const service = new GooglePlacesService();
    const result = await service.searchNearbyCompetitors("dentista", "Brasília", "place-self");
    expect(result.places.map((p) => p.placeId)).toEqual(["place-competitor"]);
  });
});

describe("PlacesServiceError", () => {
  it("é uma instância de Error com o código certo", () => {
    const error = new PlacesServiceError("TIMEOUT", "demorou demais");
    expect(error).toBeInstanceOf(Error);
    expect(error.code).toBe("TIMEOUT");
  });
});
