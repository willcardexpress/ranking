import { describe, expect, it, vi, beforeEach, afterEach } from "vitest";
import { getCached, setCached, clearCache } from "@/services/google/cache";

describe("cache do services/google", () => {
  beforeEach(() => {
    clearCache();
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it("retorna null para uma chave inexistente", () => {
    expect(getCached("nope")).toBeNull();
  });

  it("retorna o valor armazenado enquanto o TTL não expira", () => {
    setCached("search:brasilia", ["a", "b"], 1000);
    expect(getCached("search:brasilia")).toEqual(["a", "b"]);
  });

  it("expira o valor após o TTL", () => {
    setCached("search:brasilia", ["a"], 1000);
    vi.advanceTimersByTime(1001);
    expect(getCached("search:brasilia")).toBeNull();
  });

  it("clearCache remove todas as entradas", () => {
    setCached("a", 1, 5000);
    setCached("b", 2, 5000);
    clearCache();
    expect(getCached("a")).toBeNull();
    expect(getCached("b")).toBeNull();
  });
});
