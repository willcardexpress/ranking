import { describe, expect, it, beforeEach, vi, afterEach } from "vitest";

vi.mock("server-only", () => ({}));

import { checkRateLimit, resetRateLimits } from "@/services/google/rate-limiter";
import { PlacesServiceError } from "@/services/google/errors";

// A camada em banco (lib/rate-limit.ts) falha aberta quando o Supabase
// não está configurado, como é o caso neste ambiente de testes — então
// estes testes exercitam só a camada em memória, que é quem decide
// primeiro (e sozinha, já que a camada em banco nunca vai rejeitar aqui).

describe("rate limiter interno do Google Places (camada em memória)", () => {
  beforeEach(() => {
    resetRateLimits();
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it("permite requisições dentro do limite", async () => {
    for (let i = 0; i < 30; i++) {
      await expect(checkRateLimit("search")).resolves.toBeUndefined();
    }
  });

  it("lança PlacesServiceError ao exceder o limite de busca", async () => {
    for (let i = 0; i < 30; i++) await checkRateLimit("search");
    await expect(checkRateLimit("search")).rejects.toBeInstanceOf(PlacesServiceError);
  });

  it("o erro de limite interno usa o código INTERNAL_RATE_LIMITED", async () => {
    for (let i = 0; i < 30; i++) await checkRateLimit("search");
    await expect(checkRateLimit("search")).rejects.toMatchObject({ code: "INTERNAL_RATE_LIMITED" });
  });

  it("operações diferentes têm contadores independentes", async () => {
    for (let i = 0; i < 30; i++) await checkRateLimit("search");
    await expect(checkRateLimit("details")).resolves.toBeUndefined();
  });

  it("a janela reseta depois de 60 segundos", async () => {
    for (let i = 0; i < 30; i++) await checkRateLimit("search");
    vi.advanceTimersByTime(60_001);
    await expect(checkRateLimit("search")).resolves.toBeUndefined();
  });
});
