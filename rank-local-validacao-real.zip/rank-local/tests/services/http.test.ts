import { describe, expect, it, vi, beforeEach } from "vitest";
import { fetchWithRetry, UpstreamTimeoutError } from "@/services/google/http";

describe("fetchWithRetry", () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it("retorna a resposta quando a primeira tentativa é bem-sucedida", async () => {
    const okResponse = new Response("ok", { status: 200 });
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(okResponse));

    const response = await fetchWithRetry("https://example.com", { retries: 2, retryDelayMs: 1 });

    expect(response.status).toBe(200);
    expect(fetch).toHaveBeenCalledTimes(1);
  });

  it("tenta novamente em erro 500 e depois retorna sucesso", async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce(new Response("erro", { status: 500 }))
      .mockResolvedValueOnce(new Response("ok", { status: 200 }));
    vi.stubGlobal("fetch", fetchMock);

    const response = await fetchWithRetry("https://example.com", { retries: 2, retryDelayMs: 1 });

    expect(response.status).toBe(200);
    expect(fetchMock).toHaveBeenCalledTimes(2);
  });

  it("não tenta novamente em erro 400 (não retentável)", async () => {
    const fetchMock = vi.fn().mockResolvedValue(new Response("bad", { status: 400 }));
    vi.stubGlobal("fetch", fetchMock);

    const response = await fetchWithRetry("https://example.com", { retries: 2, retryDelayMs: 1 });

    expect(response.status).toBe(400);
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it("lança UpstreamTimeoutError após esgotar as tentativas com abort", async () => {
    const fetchMock = vi.fn().mockImplementation((_url: string, init?: RequestInit) => {
      return new Promise((_resolve, reject) => {
        init?.signal?.addEventListener("abort", () => {
          const error = new Error("aborted");
          error.name = "AbortError";
          reject(error);
        });
      });
    });
    vi.stubGlobal("fetch", fetchMock);

    await expect(
      fetchWithRetry("https://example.com", { retries: 0, retryDelayMs: 1, timeoutMs: 5 })
    ).rejects.toBeInstanceOf(UpstreamTimeoutError);
  });
});
