import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import path from "node:path";

const migration = readFileSync(
  path.resolve(__dirname, "../../database/migrations/0003_ranking.sql"),
  "utf-8"
);

const tables = [
  "keywords",
  "keyword_locations",
  "ranking_scans",
  "ranking_grid_points",
  "ranking_results",
];

describe("database/migrations/0003_ranking.sql", () => {
  it.each(tables)("a tabela %s tem RLS habilitado", (table) => {
    expect(migration).toMatch(new RegExp(`alter table ${table} enable row level security`, "i"));
  });

  it.each(tables)("a tabela %s tem ao menos uma policy de select", (table) => {
    const hasSelectPolicy = new RegExp(
      `create policy[^;]*on ${table} for select[\\s\\S]*?is_org_member`,
      "i"
    ).test(migration);
    expect(hasSelectPolicy).toBe(true);
  });

  it("ranking_results não guarda nome/endereço/avaliação em texto — só place_id e posição", () => {
    expect(migration).not.toMatch(/display_name|formatted_address|rating\s+numeric/i);
    expect(migration).toMatch(/top_place_ids jsonb/);
    expect(migration).toMatch(/observed_position integer/);
  });

  it("grid_size é restrito aos tamanhos suportados (3x3/5x5/7x7)", () => {
    expect(migration).toMatch(/grid_size in \('3x3', '5x5', '7x7'\)/);
  });
});
