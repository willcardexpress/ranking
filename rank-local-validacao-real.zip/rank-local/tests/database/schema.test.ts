import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import path from "node:path";

const schema = readFileSync(
  path.resolve(__dirname, "../../database/schema.sql"),
  "utf-8"
);

const tables = ["organizations", "organization_members", "businesses", "business_locations"];

describe("database/schema.sql", () => {
  it.each(tables)("a tabela %s tem RLS habilitado", (table) => {
    expect(schema).toMatch(
      new RegExp(`alter table ${table} enable row level security`, "i")
    );
  });

  it.each(tables)("a tabela %s tem ao menos uma policy de select", (table) => {
    // Garante que cada tabela tem pelo menos uma policy que restringe leitura
    // por pertencimento à organização (is_org_member).
    const hasSelectPolicy = new RegExp(
      `create policy[^;]*on ${table} for select[\\s\\S]*?is_org_member`,
      "i"
    ).test(schema);
    expect(hasSelectPolicy).toBe(true);
  });

  it("nunca referencia diretamente auth.users fora de organization_members", () => {
    const referencesOutsideMembers = schema
      .split("\n")
      .some((line) => line.includes("auth.users") && !schema.includes("organization_members"));
    expect(referencesOutsideMembers).toBe(false);
  });
});
