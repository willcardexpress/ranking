import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import path from "node:path";

const migration = readFileSync(
  path.resolve(__dirname, "../../database/migrations/0004_google_business_profile.sql"),
  "utf-8"
);

describe("database/migrations/0004_google_business_profile.sql", () => {
  it("google_business_connections tem RLS habilitado", () => {
    expect(migration).toMatch(/alter table google_business_connections enable row level security/i);
  });

  it("google_business_connections NÃO tem nenhuma policy (bloqueio total via client key)", () => {
    const hasPolicyOnConnections = /create policy[^;]*on google_business_connections/i.test(migration);
    expect(hasPolicyOnConnections).toBe(false);
  });

  it("google_business_connections guarda os tokens (access/refresh)", () => {
    expect(migration).toMatch(/access_token text not null/);
    expect(migration).toMatch(/refresh_token text/);
  });

  it("google_business_profile_data tem RLS habilitado e policy de select org-scoped", () => {
    expect(migration).toMatch(/alter table google_business_profile_data enable row level security/i);
    expect(migration).toMatch(
      /create policy[^;]*on google_business_profile_data for select[\s\S]*?is_org_member/i
    );
  });

  it("a definição da tabela google_business_profile_data não guarda tokens", () => {
    const match = migration.match(/create table if not exists google_business_profile_data \(([\s\S]*?)\n\);/);
    expect(match).not.toBeNull();
    expect(match?.[1] ?? "").not.toMatch(/access_token|refresh_token/);
  });

  it("a conexão é única por empresa (unique em business_id)", () => {
    expect(migration).toMatch(/business_id uuid not null references businesses\(id\) on delete cascade unique/);
  });
});
