import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import path from "node:path";

const migration = readFileSync(path.resolve(__dirname, "../../database/migrations/0005_seo.sql"), "utf-8");

const tables = ["website_projects", "website_pages", "seo_audits", "seo_issues"];

describe("database/migrations/0005_seo.sql", () => {
  it.each(tables)("a tabela %s tem RLS habilitado", (table) => {
    expect(migration).toMatch(new RegExp(`alter table ${table} enable row level security`, "i"));
  });

  it.each(tables)("a tabela %s tem ao menos uma policy de select", (table) => {
    const hasSelectPolicy = new RegExp(
      `create policy[^;]*on ${table} for select[\\s\\S]*?is_org_member`,
      "i"
    ).test(migration);
    expect(hasSelectPolicy).toBe(true);
  });

  it("severity de seo_issues é restrita a critical/warning/info", () => {
    expect(migration).toMatch(/severity text not null check \(severity in \('critical', 'warning', 'info'\)\)/);
  });

  it("um projeto de site é único por empresa", () => {
    expect(migration).toMatch(/business_id uuid not null references businesses\(id\) on delete cascade unique/);
  });
});
