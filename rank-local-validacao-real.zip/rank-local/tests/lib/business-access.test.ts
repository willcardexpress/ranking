import { describe, expect, it, vi, beforeEach } from "vitest";

vi.mock("server-only", () => ({}));

const getUserMock = vi.fn();
const maybeSingleMock = vi.fn();
const eqMock = vi.fn(() => ({ maybeSingle: maybeSingleMock }));
const selectMock = vi.fn(() => ({ eq: eqMock }));
const fromMock = vi.fn(() => ({ select: selectMock }));

const createClientMock = vi.fn();
vi.mock("@/lib/supabase/server", () => ({
  createClient: (...args: unknown[]) => createClientMock(...args),
}));

const { assertBusinessAccess } = await import("@/lib/business-access");

beforeEach(() => {
  getUserMock.mockReset();
  maybeSingleMock.mockReset();
  eqMock.mockClear();
  selectMock.mockClear();
  fromMock.mockClear();
  createClientMock.mockReset();
  createClientMock.mockResolvedValue({
    auth: { getUser: getUserMock },
    from: fromMock,
  });
});

describe("assertBusinessAccess", () => {
  it("rejeita quando businessId está vazio, sem nem chamar o Supabase", async () => {
    const result = await assertBusinessAccess("");
    expect(result).toEqual({ ok: false, error: "Empresa não informada." });
    expect(createClientMock).not.toHaveBeenCalled();
  });

  it("rejeita usuário não autenticado", async () => {
    getUserMock.mockResolvedValue({ data: { user: null } });

    const result = await assertBusinessAccess("biz-1");
    expect(result).toEqual({ ok: false, error: "Você precisa estar logado." });
    expect(fromMock).not.toHaveBeenCalled(); // nem chega a consultar o banco
  });

  it("rejeita quando a empresa não é encontrada (não existe OU é de outra organização)", async () => {
    getUserMock.mockResolvedValue({ data: { user: { id: "user-1" } } });
    maybeSingleMock.mockResolvedValue({ data: null, error: null });

    const result = await assertBusinessAccess("biz-de-outra-org");
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.error).toBe("Empresa não encontrada ou sem permissão de acesso.");
    }
    expect(fromMock).toHaveBeenCalledWith("businesses");
    expect(eqMock).toHaveBeenCalledWith("id", "biz-de-outra-org");
  });

  it("rejeita quando a query retorna erro (ex.: RLS bloqueou silenciosamente)", async () => {
    getUserMock.mockResolvedValue({ data: { user: { id: "user-1" } } });
    maybeSingleMock.mockResolvedValue({ data: null, error: { message: "permission denied" } });

    const result = await assertBusinessAccess("biz-1");
    expect(result.ok).toBe(false);
  });

  it("autoriza quando o usuário está logado e a empresa pertence à sua organização", async () => {
    getUserMock.mockResolvedValue({ data: { user: { id: "user-1" } } });
    maybeSingleMock.mockResolvedValue({ data: { id: "biz-1" }, error: null });

    const result = await assertBusinessAccess("biz-1");
    expect(result).toEqual({ ok: true });
  });

  it("captura falha de configuração do Supabase (createClient lança) sem propagar o erro", async () => {
    createClientMock.mockRejectedValue(new Error("Supabase env vars ausentes"));

    const result = await assertBusinessAccess("biz-1");
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.error).toBe("Supabase não configurado neste ambiente.");
    }
  });
});
