import { describe, expect, it, vi, beforeEach } from "vitest";

vi.mock("server-only", () => ({}));

const refreshAccessTokenMock = vi.fn();
vi.mock("@/services/google/business-profile", () => ({
  googleBusinessProfileService: { refreshAccessToken: (...a: unknown[]) => refreshAccessTokenMock(...a) },
}));

/** Chain "faz-tudo": thenable (resolve `result` quando `await`ado) e encadeável. */
function makeChain(result: { data?: unknown; error?: unknown }) {
  const promise = Promise.resolve(result);
  const chain: Record<string, unknown> = {
    select: () => chain,
    eq: () => chain,
    update: () => chain,
    upsert: () => chain,
    delete: () => chain,
    maybeSingle: () => promise,
    then: (onFulfilled: (v: unknown) => unknown, onRejected?: (e: unknown) => unknown) =>
      promise.then(onFulfilled, onRejected),
  };
  return chain;
}

const tableResults = new Map<string, { data?: unknown; error?: unknown }>();
const fromMock = vi.fn((table: string) => makeChain(tableResults.get(table) ?? { data: null, error: null }));

const createServiceRoleClientMock = vi.fn(() => ({ from: fromMock }));
vi.mock("@/lib/supabase/server", () => ({
  createServiceRoleClient: () => createServiceRoleClientMock(),
}));

const {
  getConnectionSummary,
  getValidAccessToken,
  saveInitialTokens,
  disconnect,
} = await import("@/lib/integrations/google-business/tokens");
const { GoogleBusinessProfileError } = await import("@/services/google/business-profile-errors");

beforeEach(() => {
  tableResults.clear();
  fromMock.mockClear();
  refreshAccessTokenMock.mockReset();
});

describe("getConnectionSummary", () => {
  it("retorna status not_connected quando não existe linha para a empresa", async () => {
    tableResults.set("google_business_connections", { data: null, error: null });
    const summary = await getConnectionSummary("biz-1");
    expect(summary.status).toBe("not_connected");
    expect(summary.googleAccountName).toBeNull();
  });

  it("mapeia os campos seguros da linha, sem incluir tokens", async () => {
    tableResults.set("google_business_connections", {
      data: {
        status: "connected",
        google_account_resource_name: "accounts/1",
        google_account_name: "Agência X",
        selected_location_resource_name: "locations/2",
        last_synced_at: "2026-09-01T00:00:00Z",
        last_error: null,
      },
      error: null,
    });
    const summary = await getConnectionSummary("biz-1");
    expect(summary).toEqual({
      status: "connected",
      googleAccountName: "Agência X",
      googleAccountResourceName: "accounts/1",
      selectedLocationResourceName: "locations/2",
      lastSyncedAt: "2026-09-01T00:00:00Z",
      lastError: null,
    });
    expect(JSON.stringify(summary)).not.toContain("token");
  });
});

describe("getValidAccessToken", () => {
  it("lança NOT_CONNECTED quando não há registro para a empresa", async () => {
    tableResults.set("google_business_connections", { data: null, error: null });
    await expect(getValidAccessToken("biz-sem-conexao")).rejects.toMatchObject({ code: "NOT_CONNECTED" });
  });

  it("lança TOKEN_REVOKED quando o status já está marcado como revogado", async () => {
    tableResults.set("google_business_connections", {
      data: { status: "revoked", access_token: "x", refresh_token: "y", token_expires_at: new Date(Date.now() + 100000).toISOString() },
      error: null,
    });
    await expect(getValidAccessToken("biz-1")).rejects.toMatchObject({ code: "TOKEN_REVOKED" });
  });

  it("retorna o access_token existente quando ele ainda não está perto de expirar", async () => {
    tableResults.set("google_business_connections", {
      data: {
        status: "connected",
        access_token: "token-ainda-valido",
        refresh_token: "refresh-token",
        token_expires_at: new Date(Date.now() + 10 * 60 * 1000).toISOString(), // expira em 10min
      },
      error: null,
    });
    const token = await getValidAccessToken("biz-1");
    expect(token).toBe("token-ainda-valido");
    expect(refreshAccessTokenMock).not.toHaveBeenCalled();
  });

  it("renova automaticamente quando o token está prestes a expirar e há refresh_token", async () => {
    tableResults.set("google_business_connections", {
      data: {
        status: "connected",
        access_token: "token-velho",
        refresh_token: "refresh-token",
        token_expires_at: new Date(Date.now() + 30 * 1000).toISOString(), // expira em 30s (< margem de 1min)
      },
      error: null,
    });
    refreshAccessTokenMock.mockResolvedValue({
      accessToken: "token-novo",
      refreshToken: "refresh-token",
      expiresAt: new Date(Date.now() + 3600 * 1000).toISOString(),
      scope: "business.manage",
    });

    const token = await getValidAccessToken("biz-1");
    expect(token).toBe("token-novo");
    expect(refreshAccessTokenMock).toHaveBeenCalledWith("refresh-token");
  });

  it("lança TOKEN_EXPIRED quando o token expirou e não há refresh_token para renovar", async () => {
    tableResults.set("google_business_connections", {
      data: {
        status: "connected",
        access_token: "token-velho",
        refresh_token: null,
        token_expires_at: new Date(Date.now() - 1000).toISOString(),
      },
      error: null,
    });
    await expect(getValidAccessToken("biz-1")).rejects.toMatchObject({ code: "TOKEN_EXPIRED" });
  });

  it("propaga TOKEN_REVOKED quando a renovação falha por revogação no Google", async () => {
    tableResults.set("google_business_connections", {
      data: {
        status: "connected",
        access_token: "token-velho",
        refresh_token: "refresh-token",
        token_expires_at: new Date(Date.now() - 1000).toISOString(),
      },
      error: null,
    });
    refreshAccessTokenMock.mockRejectedValue(
      new GoogleBusinessProfileError("TOKEN_REVOKED", "revogado pelo usuário")
    );

    await expect(getValidAccessToken("biz-1")).rejects.toMatchObject({ code: "TOKEN_REVOKED" });
  });
});

describe("saveInitialTokens", () => {
  it("lança UPSTREAM_ERROR quando a gravação no banco falha", async () => {
    tableResults.set("google_business_connections", { data: null, error: { message: "constraint violation" } });
    await expect(
      saveInitialTokens("biz-1", "user-1", {
        accessToken: "at",
        refreshToken: "rt",
        expiresAt: new Date().toISOString(),
        scope: "business.manage",
      })
    ).rejects.toMatchObject({ code: "UPSTREAM_ERROR" });
  });

  it("conclui sem erro quando a gravação é bem-sucedida", async () => {
    tableResults.set("google_business_connections", { data: null, error: null });
    await expect(
      saveInitialTokens("biz-1", "user-1", {
        accessToken: "at",
        refreshToken: "rt",
        expiresAt: new Date().toISOString(),
        scope: "business.manage",
      })
    ).resolves.toBeUndefined();
  });
});

describe("disconnect", () => {
  it("remove a linha tanto de google_business_connections quanto de google_business_profile_data", async () => {
    tableResults.set("google_business_connections", { data: null, error: null });
    tableResults.set("google_business_profile_data", { data: null, error: null });

    await disconnect("biz-1");

    const calledTables = fromMock.mock.calls.map((c) => c[0]);
    expect(calledTables).toContain("google_business_connections");
    expect(calledTables).toContain("google_business_profile_data");
  });
});
