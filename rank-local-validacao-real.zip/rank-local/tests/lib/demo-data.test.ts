import { describe, expect, it } from "vitest";
import { demoBusinesses, demoDashboardSnapshot } from "@/lib/demo-data";

describe("dados demonstrativos da Fase 1", () => {
  it("toda empresa mockada está marcada como is_demo", () => {
    expect(demoBusinesses.length).toBeGreaterThan(0);
    for (const business of demoBusinesses) {
      expect(business.is_demo).toBe(true);
    }
  });

  it("o snapshot do dashboard está marcado como is_demo", () => {
    expect(demoDashboardSnapshot.is_demo).toBe(true);
  });

  it("as métricas proprietárias ficam dentro da faixa 0-100", () => {
    const { rank_local_index, ai_visibility_score, seo_score, reputation_score } =
      demoDashboardSnapshot;
    for (const score of [rank_local_index, ai_visibility_score, seo_score, reputation_score]) {
      expect(score).toBeGreaterThanOrEqual(0);
      expect(score).toBeLessThanOrEqual(100);
    }
  });
});
