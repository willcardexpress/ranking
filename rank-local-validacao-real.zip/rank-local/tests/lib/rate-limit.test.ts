import { describe, expect, it, vi, beforeEach } from "vitest";

vi.mock("server-only", () => ({}));

const rpcMock = vi.fn();
const createServiceRoleClientMock = vi.fn(() => ({ rpc: rpcMock }));
vi.mock("@/lib/supabase/server", () => ({
  createServiceRoleClient: () => createServiceRoleClientMock(),
}));

const { checkDbRateLimit, RateLimitExceededError } = await import("@/lib/rate-limit");

beforeEach(() => {
  rpcMock.mockReset();
  createServiceRoleClientMock.mockClear();
});

describe("checkDbRateLimit", () => {
  it("permite a requisição quando a contagem está dentro do limite", async () => {
    rpcMock.mockResolvedValue({ data: 5, error: null });
    await expect(checkDbRateLimit("teste:op", 10)).resolves.toBeUndefined();
  });

  it("lança RateLimitExceededError quando a contagem ultrapassa o limite", async () => {
    rpcMock.mockResolvedValue({ data: 11, error: null });
    await expect(checkDbRateLimit("teste:op", 10)).rejects.toBeInstanceOf(RateLimitExceededError);
  });

  it("chama a RPC com o nome e os parâmetros corretos", async () => {
    rpcMock.mockResolvedValue({ data: 1, error: null });
    await checkDbRateLimit("google:search", 30, 60_000);
    expect(rpcMock).toHaveBeenCalledWith(
      "increment_rate_limit_counter",
      expect.objectContaining({ p_key: "google:search" })
    );
  });

  it("falha aberta (não bloqueia) quando a RPC retorna erro", async () => {
    rpcMock.mockResolvedValue({ data: null, error: { message: "function does not exist" } });
    await expect(checkDbRateLimit("teste:op", 10)).resolves.toBeUndefined();
  });

  it("falha aberta quando createServiceRoleClient lança (Supabase não configurado)", async () => {
    createServiceRoleClientMock.mockImplementation(() => {
      throw new Error("SUPABASE_SERVICE_ROLE_KEY ausente");
    });
    await expect(checkDbRateLimit("teste:op", 10)).resolves.toBeUndefined();
  });
});
