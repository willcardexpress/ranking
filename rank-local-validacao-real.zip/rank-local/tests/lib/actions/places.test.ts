import { describe, expect, it, vi, beforeEach } from "vitest";

vi.mock("server-only", () => ({}));

const requireAuthenticatedUserMock = vi.fn();
vi.mock("@/lib/business-access", () => ({
  requireAuthenticatedUser: () => requireAuthenticatedUserMock(),
}));

const searchTextMock = vi.fn();
const getDetailsMock = vi.fn();
const searchNearbyCompetitorsMock = vi.fn();
vi.mock("@/services/google/places", () => ({
  googlePlacesService: {
    searchText: (...a: unknown[]) => searchTextMock(...a),
    getDetails: (...a: unknown[]) => getDetailsMock(...a),
    searchNearbyCompetitors: (...a: unknown[]) => searchNearbyCompetitorsMock(...a),
  },
}));

const isGooglePlacesConfiguredMock = vi.fn();
vi.mock("@/services/google/config", () => ({
  isGooglePlacesConfigured: () => isGooglePlacesConfiguredMock(),
}));

const { searchPlacesAction, confirmPlaceAction, searchCompetitorsAction, checkGooglePlacesConfigured } =
  await import("@/lib/actions/places");
const { PlacesServiceError } = await import("@/services/google/errors");

function formData(fields: Record<string, string>) {
  const fd = new FormData();
  for (const [k, v] of Object.entries(fields)) fd.set(k, v);
  return fd;
}

beforeEach(() => {
  searchTextMock.mockReset();
  getDetailsMock.mockReset();
  searchNearbyCompetitorsMock.mockReset();
  isGooglePlacesConfiguredMock.mockReset();
  requireAuthenticatedUserMock.mockReset();
  requireAuthenticatedUserMock.mockResolvedValue({ ok: true }); // padrão: usuário autenticado
});

describe("checkGooglePlacesConfigured", () => {
  it("reflete o valor de isGooglePlacesConfigured", async () => {
    isGooglePlacesConfiguredMock.mockReturnValue(true);
    await expect(checkGooglePlacesConfigured()).resolves.toBe(true);
  });
});

describe("searchPlacesAction", () => {
  it("recusa quando o usuário não está autenticado, sem chamar o Google", async () => {
    requireAuthenticatedUserMock.mockResolvedValue({ ok: false, error: "Você precisa estar logado." });
    const result = await searchPlacesAction(null, formData({ query: "dentista em brasília" }));
    expect(result?.error).toBe("Você precisa estar logado.");
    expect(isGooglePlacesConfiguredMock).not.toHaveBeenCalled();
  });

  it("recusa quando o Google Places não está configurado", async () => {
    isGooglePlacesConfiguredMock.mockReturnValue(false);
    const result = await searchPlacesAction(null, formData({ query: "dentista em brasília" }));
    expect(result?.error).toContain("não conectado");
    expect(searchTextMock).not.toHaveBeenCalled();
  });

  it("recusa queries muito curtas", async () => {
    isGooglePlacesConfiguredMock.mockReturnValue(true);
    const result = await searchPlacesAction(null, formData({ query: "ab" }));
    expect(result?.error).toContain("3 caracteres");
  });

  it("retorna os resultados encontrados", async () => {
    isGooglePlacesConfiguredMock.mockReturnValue(true);
    searchTextMock.mockResolvedValue({ places: [{ placeId: "p1", displayName: "Empresa X" }], fromCache: false });
    const result = await searchPlacesAction(null, formData({ query: "dentista em brasília" }));
    expect(result?.results).toHaveLength(1);
  });

  it("mapeia PlacesServiceError para uma mensagem amigável", async () => {
    isGooglePlacesConfiguredMock.mockReturnValue(true);
    searchTextMock.mockRejectedValue(new PlacesServiceError("RATE_LIMITED", "..."));
    const result = await searchPlacesAction(null, formData({ query: "dentista em brasília" }));
    expect(result?.error).toContain("Limite de requisições");
  });
});

describe("confirmPlaceAction", () => {
  it("recusa quando o usuário não está autenticado", async () => {
    requireAuthenticatedUserMock.mockResolvedValue({ ok: false, error: "Você precisa estar logado." });
    const result = await confirmPlaceAction("place-1");
    expect(result).toEqual({ ok: false, error: "Você precisa estar logado." });
  });

  it("recusa quando o Google Places não está configurado", async () => {
    isGooglePlacesConfiguredMock.mockReturnValue(false);
    const result = await confirmPlaceAction("place-1");
    expect(result).toEqual({ ok: false, error: "Google Places não conectado." });
  });

  it("retorna o place em caso de sucesso", async () => {
    isGooglePlacesConfiguredMock.mockReturnValue(true);
    getDetailsMock.mockResolvedValue({ placeId: "place-1", displayName: "Empresa X" });
    const result = await confirmPlaceAction("place-1");
    expect(result).toEqual({ ok: true, place: { placeId: "place-1", displayName: "Empresa X" } });
  });

  it("mapeia erro de place não encontrado", async () => {
    isGooglePlacesConfiguredMock.mockReturnValue(true);
    getDetailsMock.mockRejectedValue(new PlacesServiceError("INVALID_REQUEST", "não encontrado"));
    const result = await confirmPlaceAction("place-inexistente");
    expect(result).toEqual({ ok: false, error: "não encontrado" });
  });
});

describe("searchCompetitorsAction", () => {
  it("recusa quando o usuário não está autenticado", async () => {
    requireAuthenticatedUserMock.mockResolvedValue({ ok: false, error: "Você precisa estar logado." });
    const result = await searchCompetitorsAction("dentista", "Brasília");
    expect(result).toEqual({ ok: false, error: "Você precisa estar logado." });
  });

  it("recusa quando o Google Places não está configurado", async () => {
    isGooglePlacesConfiguredMock.mockReturnValue(false);
    const result = await searchCompetitorsAction("dentista", "Brasília");
    expect(result).toEqual({ ok: false, error: "Google Places não conectado." });
  });

  it("recusa sem categoria/área de atuação", async () => {
    isGooglePlacesConfiguredMock.mockReturnValue(true);
    const result = await searchCompetitorsAction("", "");
    expect(result.ok).toBe(false);
  });

  it("retorna os concorrentes encontrados", async () => {
    isGooglePlacesConfiguredMock.mockReturnValue(true);
    searchNearbyCompetitorsMock.mockResolvedValue({ places: [{ placeId: "c1" }], fromCache: false });
    const result = await searchCompetitorsAction("dentista", "Brasília", "place-self");
    expect(result).toEqual({ ok: true, competitors: [{ placeId: "c1" }] });
    expect(searchNearbyCompetitorsMock).toHaveBeenCalledWith("dentista", "Brasília", "place-self");
  });
});
