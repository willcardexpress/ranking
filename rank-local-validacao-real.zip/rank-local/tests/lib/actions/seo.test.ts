import { describe, expect, it, vi, beforeEach } from "vitest";

vi.mock("server-only", () => ({}));
vi.mock("next/cache", () => ({ revalidatePath: vi.fn() }));

const assertBusinessAccessMock = vi.fn();
vi.mock("@/lib/business-access", () => ({
  assertBusinessAccess: (...a: unknown[]) => assertBusinessAccessMock(...a),
}));

const auditWebsiteMock = vi.fn();
vi.mock("@/services/seo/crawler", () => ({
  seoCrawlerService: { auditWebsite: (...a: unknown[]) => auditWebsiteMock(...a) },
}));

const assertHostnameIsPublicMock = vi.fn();
vi.mock("@/services/seo/safe-fetch", () => ({
  assertHostnameIsPublic: (...a: unknown[]) => assertHostnameIsPublicMock(...a),
}));

function makeSupabaseMock() {
  const queues = new Map<string, { data?: unknown; error?: unknown }[]>();
  const calls: { table: string; method: string }[] = [];

  function enqueue(table: string, result: { data?: unknown; error?: unknown }) {
    if (!queues.has(table)) queues.set(table, []);
    queues.get(table)!.push(result);
  }
  function nextResult(table: string) {
    const q = queues.get(table);
    if (q && q.length > 0) return q.shift()!;
    return { data: null, error: null };
  }

  const getUserMock = vi.fn();

  const from = vi.fn((table: string) => {
    const chain: Record<string, unknown> = {
      select: () => { calls.push({ table, method: "select" }); return chain; },
      eq: () => chain,
      order: () => chain,
      insert: () => { calls.push({ table, method: "insert" }); return chain; },
      update: () => { calls.push({ table, method: "update" }); return chain; },
      upsert: () => { calls.push({ table, method: "upsert" }); return chain; },
      delete: () => { calls.push({ table, method: "delete" }); return chain; },
      maybeSingle: () => Promise.resolve(nextResult(table)),
      single: () => Promise.resolve(nextResult(table)),
      then: (onFulfilled: (v: unknown) => unknown, onRejected?: (e: unknown) => unknown) =>
        Promise.resolve(nextResult(table)).then(onFulfilled, onRejected),
    };
    return chain;
  });

  return { auth: { getUser: getUserMock }, from, enqueue, calls };
}

const supabaseMock = { current: makeSupabaseMock() };
vi.mock("@/lib/supabase/server", () => ({
  createClient: () => Promise.resolve(supabaseMock.current),
}));

const { saveWebsiteProjectAction, runSeoAuditAction } = await import("@/lib/actions/seo");
const { SeoServiceError } = await import("@/services/seo/errors");

function formData(fields: Record<string, string>) {
  const fd = new FormData();
  for (const [k, v] of Object.entries(fields)) fd.set(k, v);
  return fd;
}

beforeEach(() => {
  assertBusinessAccessMock.mockReset();
  auditWebsiteMock.mockReset();
  assertHostnameIsPublicMock.mockReset();
  supabaseMock.current = makeSupabaseMock();
});

describe("saveWebsiteProjectAction", () => {
  const BIZ_ID = "11111111-1111-4111-8111-111111111111";

  it("rejeita dados inválidos (sem businessId válido)", async () => {
    const result = await saveWebsiteProjectAction(null, formData({ businessId: "não-é-uuid", rootUrl: "exemplo.com" }));
    expect(result?.error).toBeTruthy();
    expect(assertBusinessAccessMock).not.toHaveBeenCalled();
  });

  it("propaga o erro de assertBusinessAccess (usuário sem acesso à empresa)", async () => {
    assertBusinessAccessMock.mockResolvedValue({ ok: false, error: "Empresa não encontrada ou sem permissão de acesso." });
    const result = await saveWebsiteProjectAction(null, formData({ businessId: BIZ_ID, rootUrl: "exemplo.com" }));
    expect(result?.error).toBe("Empresa não encontrada ou sem permissão de acesso.");
  });

  it("bloqueia quando a URL aponta para um host privado (SSRF)", async () => {
    assertBusinessAccessMock.mockResolvedValue({ ok: true });
    assertHostnameIsPublicMock.mockRejectedValue(
      new SeoServiceError("SSRF_BLOCKED", "endereço privado")
    );
    const result = await saveWebsiteProjectAction(null, formData({ businessId: BIZ_ID, rootUrl: "http://localhost/" }));
    expect(result?.error).toContain("endereço interno/privado");
  });

  it("salva o site quando tudo é válido", async () => {
    assertBusinessAccessMock.mockResolvedValue({ ok: true });
    assertHostnameIsPublicMock.mockResolvedValue(undefined);
    supabaseMock.current.enqueue("website_projects", { error: null });

    const result = await saveWebsiteProjectAction(null, formData({ businessId: BIZ_ID, rootUrl: "exemplo.com.br" }));
    expect(result).toEqual({ success: true });
  });
});

describe("runSeoAuditAction", () => {
  const BIZ_ID = "22222222-2222-4222-8222-222222222222";

  it("propaga o erro de assertBusinessAccess", async () => {
    assertBusinessAccessMock.mockResolvedValue({ ok: false, error: "Empresa não encontrada ou sem permissão de acesso." });
    const result = await runSeoAuditAction(BIZ_ID);
    expect(result).toEqual({ ok: false, error: "Empresa não encontrada ou sem permissão de acesso." });
  });

  it("rejeita quando não há usuário autenticado", async () => {
    assertBusinessAccessMock.mockResolvedValue({ ok: true });
    supabaseMock.current.auth.getUser.mockResolvedValue({ data: { user: null } });
    const result = await runSeoAuditAction(BIZ_ID);
    expect(result).toEqual({ ok: false, error: "Você precisa estar logado." });
  });

  it("pede para cadastrar o site quando não há website_projects", async () => {
    assertBusinessAccessMock.mockResolvedValue({ ok: true });
    supabaseMock.current.auth.getUser.mockResolvedValue({ data: { user: { id: "user-1" } } });
    supabaseMock.current.enqueue("website_projects", { data: null });

    const result = await runSeoAuditAction(BIZ_ID);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.error).toContain("Cadastre a URL do site");
  });

  it("recusa uma nova auditoria quando já existe uma em andamento (recente)", async () => {
    assertBusinessAccessMock.mockResolvedValue({ ok: true });
    supabaseMock.current.auth.getUser.mockResolvedValue({ data: { user: { id: "user-1" } } });
    supabaseMock.current.enqueue("website_projects", { data: { id: "proj-1", root_url: "https://exemplo.com.br" } });
    supabaseMock.current.enqueue("seo_audits", {
      data: { id: "audit-em-andamento", started_at: new Date().toISOString() },
      error: null,
    });

    const result = await runSeoAuditAction(BIZ_ID);
    expect(result).toEqual({ ok: false, error: "Já existe uma auditoria em andamento para este site. Aguarde ela terminar." });
    expect(auditWebsiteMock).not.toHaveBeenCalled();
  });

  it("recusa e trata violação de unicidade (23505) como 'já em andamento'", async () => {
    assertBusinessAccessMock.mockResolvedValue({ ok: true });
    supabaseMock.current.auth.getUser.mockResolvedValue({ data: { user: { id: "user-1" } } });
    supabaseMock.current.enqueue("website_projects", { data: { id: "proj-1", root_url: "https://exemplo.com.br" } });
    supabaseMock.current.enqueue("seo_audits", { data: null, error: null }); // checagem: nenhuma "running" visível
    supabaseMock.current.enqueue("seo_audits", { data: null, error: { code: "23505" } }); // insert perde a corrida

    const result = await runSeoAuditAction(BIZ_ID);
    expect(result).toEqual({ ok: false, error: "Já existe uma auditoria em andamento para este site. Aguarde ela terminar." });
  });

  it("recupera automaticamente de uma auditoria travada (running há mais de 5 minutos) e roda uma nova", async () => {
    assertBusinessAccessMock.mockResolvedValue({ ok: true });
    supabaseMock.current.auth.getUser.mockResolvedValue({ data: { user: { id: "user-1" } } });
    supabaseMock.current.enqueue("website_projects", { data: { id: "proj-1", root_url: "https://exemplo.com.br" } });
    supabaseMock.current.enqueue("seo_audits", {
      data: { id: "audit-travado", started_at: new Date(Date.now() - 10 * 60 * 1000).toISOString() },
      error: null,
    }); // checagem: encontra a auditoria travada
    supabaseMock.current.enqueue("seo_audits", { error: null }); // update marcando a travada como failed
    supabaseMock.current.enqueue("seo_audits", { data: { id: "audit-novo" }, error: null }); // insert da nova auditoria

    auditWebsiteMock.mockResolvedValue({
      rootUrl: "https://exemplo.com.br",
      pages: [{ url: "https://exemplo.com.br/", statusCode: 200 }],
      issues: [],
      seoScore: 90,
      hasRobotsTxt: true,
      hasSitemap: true,
    });

    const result = await runSeoAuditAction(BIZ_ID);
    expect(result).toEqual({ ok: true, auditId: "audit-novo" });

    const staleUpdate = supabaseMock.current.calls.find((c) => c.table === "seo_audits" && c.method === "update");
    expect(staleUpdate).toBeTruthy();
  });

  it("marca a auditoria como failed quando o crawler lança um erro", async () => {
    assertBusinessAccessMock.mockResolvedValue({ ok: true });
    supabaseMock.current.auth.getUser.mockResolvedValue({ data: { user: { id: "user-1" } } });
    supabaseMock.current.enqueue("website_projects", { data: { id: "proj-1", root_url: "https://exemplo.com.br" } });
    supabaseMock.current.enqueue("seo_audits", { data: null, error: null }); // checagem de auditoria travada (nenhuma em andamento)
    supabaseMock.current.enqueue("seo_audits", { data: { id: "audit-1" }, error: null }); // insert inicial
    auditWebsiteMock.mockRejectedValue(new SeoServiceError("NO_PAGES_CRAWLED", "sem páginas"));

    const result = await runSeoAuditAction(BIZ_ID);
    expect(result.ok).toBe(false);

    const failedUpdate = supabaseMock.current.calls.find((c) => c.table === "seo_audits" && c.method === "update");
    expect(failedUpdate).toBeTruthy();
  });

  it("conclui a auditoria com sucesso e grava os issues encontrados", async () => {
    assertBusinessAccessMock.mockResolvedValue({ ok: true });
    supabaseMock.current.auth.getUser.mockResolvedValue({ data: { user: { id: "user-1" } } });
    supabaseMock.current.enqueue("website_projects", { data: { id: "proj-1", root_url: "https://exemplo.com.br" } });
    supabaseMock.current.enqueue("seo_audits", { data: null, error: null }); // checagem de auditoria travada (nenhuma em andamento)
    supabaseMock.current.enqueue("seo_audits", { data: { id: "audit-1" }, error: null }); // insert inicial
    supabaseMock.current.enqueue("website_pages", { data: { id: "page-1", url: "https://exemplo.com.br/" } });

    auditWebsiteMock.mockResolvedValue({
      rootUrl: "https://exemplo.com.br",
      pages: [{ url: "https://exemplo.com.br/", statusCode: 200 }],
      issues: [{ pageUrl: "https://exemplo.com.br/", type: "missing_title", severity: "critical", message: "sem title" }],
      seoScore: 80,
      hasRobotsTxt: true,
      hasSitemap: false,
    });

    const result = await runSeoAuditAction(BIZ_ID);
    expect(result).toEqual({ ok: true, auditId: "audit-1" });

    const issuesInsert = supabaseMock.current.calls.find((c) => c.table === "seo_issues" && c.method === "insert");
    expect(issuesInsert).toBeTruthy();
  });

  it("não quebra quando não há nenhum problema encontrado (0 issues)", async () => {
    assertBusinessAccessMock.mockResolvedValue({ ok: true });
    supabaseMock.current.auth.getUser.mockResolvedValue({ data: { user: { id: "user-1" } } });
    supabaseMock.current.enqueue("website_projects", { data: { id: "proj-1", root_url: "https://exemplo.com.br" } });
    supabaseMock.current.enqueue("seo_audits", { data: null, error: null }); // checagem de auditoria travada (nenhuma em andamento)
    supabaseMock.current.enqueue("seo_audits", { data: { id: "audit-1" }, error: null }); // insert inicial

    auditWebsiteMock.mockResolvedValue({
      rootUrl: "https://exemplo.com.br",
      pages: [{ url: "https://exemplo.com.br/", statusCode: 200 }],
      issues: [],
      seoScore: 100,
      hasRobotsTxt: true,
      hasSitemap: true,
    });

    const result = await runSeoAuditAction(BIZ_ID);
    expect(result).toEqual({ ok: true, auditId: "audit-1" });
  });
});
