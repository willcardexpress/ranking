import { describe, expect, it, vi, beforeEach } from "vitest";

vi.mock("server-only", () => ({}));
vi.mock("next/cache", () => ({ revalidatePath: vi.fn() }));

const assertBusinessAccessMock = vi.fn();
vi.mock("@/lib/business-access", () => ({
  assertBusinessAccess: (...a: unknown[]) => assertBusinessAccessMock(...a),
}));

const searchTextAtLocationMock = vi.fn();
vi.mock("@/services/google/places", () => ({
  googlePlacesService: { searchTextAtLocation: (...a: unknown[]) => searchTextAtLocationMock(...a) },
}));

const isGooglePlacesConfiguredMock = vi.fn();
vi.mock("@/services/google/config", () => ({
  isGooglePlacesConfigured: () => isGooglePlacesConfiguredMock(),
}));

const persistConfirmedPlaceMock = vi.fn();
vi.mock("@/lib/places-persistence", () => ({
  persistConfirmedPlace: (...a: unknown[]) => persistConfirmedPlaceMock(...a),
}));

function makeSupabaseMock() {
  const queues = new Map<string, { data?: unknown; error?: unknown }[]>();
  const calls: { table: string; method: string }[] = [];

  function enqueue(table: string, result: { data?: unknown; error?: unknown }) {
    if (!queues.has(table)) queues.set(table, []);
    queues.get(table)!.push(result);
  }
  function nextResult(table: string) {
    const q = queues.get(table);
    if (q && q.length > 0) return q.shift()!;
    return { data: null, error: null };
  }

  const getUserMock = vi.fn();

  const from = vi.fn((table: string) => {
    const chain: Record<string, unknown> = {
      select: () => { calls.push({ table, method: "select" }); return chain; },
      eq: () => chain,
      order: () => chain,
      limit: () => chain,
      insert: () => { calls.push({ table, method: "insert" }); return chain; },
      update: () => { calls.push({ table, method: "update" }); return chain; },
      maybeSingle: () => Promise.resolve(nextResult(table)),
      single: () => Promise.resolve(nextResult(table)),
      then: (onFulfilled: (v: unknown) => unknown, onRejected?: (e: unknown) => unknown) =>
        Promise.resolve(nextResult(table)).then(onFulfilled, onRejected),
    };
    return chain;
  });

  return { auth: { getUser: getUserMock }, from, enqueue, calls };
}

const supabaseMock = { current: makeSupabaseMock() };
vi.mock("@/lib/supabase/server", () => ({
  createClient: () => Promise.resolve(supabaseMock.current),
}));

const { createKeywordAction, createKeywordLocationAction, runRankingScanAction } = await import(
  "@/lib/actions/ranking"
);

function formData(fields: Record<string, string>) {
  const fd = new FormData();
  for (const [k, v] of Object.entries(fields)) fd.set(k, v);
  return fd;
}

beforeEach(() => {
  searchTextAtLocationMock.mockReset();
  isGooglePlacesConfiguredMock.mockReset();
  persistConfirmedPlaceMock.mockReset();
  assertBusinessAccessMock.mockReset();
  assertBusinessAccessMock.mockResolvedValue({ ok: true }); // padrão: usuário autorizado
  supabaseMock.current = makeSupabaseMock();
});

const BIZ_ID = "11111111-1111-4111-8111-111111111111";
const KEYWORD_ID = "22222222-2222-4222-8222-222222222222";
const LOCATION_ID = "33333333-3333-4333-8333-333333333333";

describe("createKeywordAction", () => {
  it("rejeita term curto demais", async () => {
    const result = await createKeywordAction(null, formData({ businessId: BIZ_ID, term: "ab" }));
    expect(result?.error).toBeTruthy();
  });

  it("rejeita quando o usuário não tem acesso à empresa", async () => {
    assertBusinessAccessMock.mockResolvedValue({ ok: false, error: "Empresa não encontrada ou sem permissão de acesso." });
    const result = await createKeywordAction(null, formData({ businessId: BIZ_ID, term: "troca de bateria" }));
    expect(result?.error).toBe("Empresa não encontrada ou sem permissão de acesso.");
  });

  it("trata violação de unique constraint com mensagem amigável", async () => {
    supabaseMock.current.enqueue("keywords", { error: { code: "23505" } });
    const result = await createKeywordAction(null, formData({ businessId: BIZ_ID, term: "troca de bateria" }));
    expect(result?.error).toBe("Essa palavra-chave já está cadastrada para esta empresa.");
  });

  it("salva a keyword com sucesso", async () => {
    supabaseMock.current.enqueue("keywords", { error: null });
    const result = await createKeywordAction(null, formData({ businessId: BIZ_ID, term: "troca de bateria" }));
    expect(result).toEqual({ success: true });
  });
});

describe("createKeywordLocationAction", () => {
  it("rejeita latitude/longitude inválidas", async () => {
    const result = await createKeywordLocationAction(
      null,
      formData({ keywordId: KEYWORD_ID, label: "Sede", latitude: "999", longitude: "0" })
    );
    expect(result?.error).toBeTruthy();
  });

  it("rejeita quando a keyword não é encontrada (inexistente ou de outra organização)", async () => {
    supabaseMock.current.enqueue("keywords", { data: null, error: null });
    const result = await createKeywordLocationAction(
      null,
      formData({ keywordId: KEYWORD_ID, label: "Sede", latitude: "-15.8", longitude: "-47.9" })
    );
    expect(result?.error).toContain("não encontrada");
    expect(assertBusinessAccessMock).not.toHaveBeenCalled();
  });

  it("rejeita quando o usuário não tem acesso à empresa dona da keyword", async () => {
    supabaseMock.current.enqueue("keywords", { data: { business_id: BIZ_ID }, error: null });
    assertBusinessAccessMock.mockResolvedValue({ ok: false, error: "Empresa não encontrada ou sem permissão de acesso." });

    const result = await createKeywordLocationAction(
      null,
      formData({ keywordId: KEYWORD_ID, label: "Sede", latitude: "-15.8", longitude: "-47.9" })
    );
    expect(result?.error).toBe("Empresa não encontrada ou sem permissão de acesso.");
  });

  it("salva o ponto de referência com sucesso", async () => {
    supabaseMock.current.enqueue("keywords", { data: { business_id: BIZ_ID }, error: null });
    supabaseMock.current.enqueue("keyword_locations", { error: null });
    const result = await createKeywordLocationAction(
      null,
      formData({ keywordId: KEYWORD_ID, label: "Sede", latitude: "-15.8", longitude: "-47.9" })
    );
    expect(result).toEqual({ success: true });
    expect(assertBusinessAccessMock).toHaveBeenCalledWith(BIZ_ID);
  });
});

describe("runRankingScanAction", () => {
  it("recusa quando o Google Places não está configurado", async () => {
    isGooglePlacesConfiguredMock.mockReturnValue(false);
    const result = await runRankingScanAction(LOCATION_ID, "3x3");
    expect(result).toEqual({
      ok: false,
      error: "Google Places não conectado. Configure GOOGLE_PLACES_API_KEY para rodar um scan.",
    });
  });

  it("recusa quando não há usuário autenticado", async () => {
    isGooglePlacesConfiguredMock.mockReturnValue(true);
    supabaseMock.current.auth.getUser.mockResolvedValue({ data: { user: null } });
    const result = await runRankingScanAction(LOCATION_ID, "3x3");
    expect(result).toEqual({ ok: false, error: "Você precisa estar logado." });
  });

  it("recusa quando o ponto de referência não é encontrado (outra organização ou inexistente)", async () => {
    isGooglePlacesConfiguredMock.mockReturnValue(true);
    supabaseMock.current.auth.getUser.mockResolvedValue({ data: { user: { id: "user-1" } } });
    supabaseMock.current.enqueue("keyword_locations", { data: null, error: null });

    const result = await runRankingScanAction(LOCATION_ID, "3x3");
    expect(result).toEqual({ ok: false, error: "Ponto de referência não encontrado." });
  });

  it("recusa quando a empresa não tem Place ID vinculado", async () => {
    isGooglePlacesConfiguredMock.mockReturnValue(true);
    supabaseMock.current.auth.getUser.mockResolvedValue({ data: { user: { id: "user-1" } } });
    supabaseMock.current.enqueue("keyword_locations", {
      data: {
        id: LOCATION_ID,
        latitude: -15.8,
        longitude: -47.9,
        keyword_id: KEYWORD_ID,
        keywords: { id: KEYWORD_ID, term: "troca de bateria", business_id: BIZ_ID, businesses: { id: BIZ_ID, google_place_id: null } },
      },
      error: null,
    });

    const result = await runRankingScanAction(LOCATION_ID, "3x3");
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.error).toContain("Place ID vinculado");
  });

  it("recusa um novo scan quando já existe um em andamento (recente)", async () => {
    isGooglePlacesConfiguredMock.mockReturnValue(true);
    supabaseMock.current.auth.getUser.mockResolvedValue({ data: { user: { id: "user-1" } } });
    supabaseMock.current.enqueue("keyword_locations", {
      data: {
        id: LOCATION_ID,
        latitude: -15.8,
        longitude: -47.9,
        keyword_id: KEYWORD_ID,
        keywords: {
          id: KEYWORD_ID,
          term: "troca de bateria",
          business_id: BIZ_ID,
          businesses: { id: BIZ_ID, google_place_id: "place-alvo" },
        },
      },
      error: null,
    });
    supabaseMock.current.enqueue("ranking_scans", {
      data: { id: "scan-em-andamento", started_at: new Date().toISOString() },
      error: null,
    });

    const result = await runRankingScanAction(LOCATION_ID, "3x3");
    expect(result).toEqual({ ok: false, error: "Já existe um scan em andamento para este ponto de referência. Aguarde ele terminar." });
    expect(searchTextAtLocationMock).not.toHaveBeenCalled();
  });

  it("trata violação de unicidade (23505) no insert como 'já em andamento'", async () => {
    isGooglePlacesConfiguredMock.mockReturnValue(true);
    supabaseMock.current.auth.getUser.mockResolvedValue({ data: { user: { id: "user-1" } } });
    supabaseMock.current.enqueue("keyword_locations", {
      data: {
        id: LOCATION_ID,
        latitude: -15.8,
        longitude: -47.9,
        keyword_id: KEYWORD_ID,
        keywords: {
          id: KEYWORD_ID,
          term: "troca de bateria",
          business_id: BIZ_ID,
          businesses: { id: BIZ_ID, google_place_id: "place-alvo" },
        },
      },
      error: null,
    });
    supabaseMock.current.enqueue("ranking_scans", { data: null, error: null }); // checagem: nenhum visível
    supabaseMock.current.enqueue("ranking_scans", { data: null, error: { code: "23505" } }); // insert perde a corrida

    const result = await runRankingScanAction(LOCATION_ID, "3x3");
    expect(result).toEqual({ ok: false, error: "Já existe um scan em andamento para este ponto de referência. Aguarde ele terminar." });
  });

  it("recupera automaticamente de um scan travado (running há mais de 5 minutos)", async () => {
    isGooglePlacesConfiguredMock.mockReturnValue(true);
    supabaseMock.current.auth.getUser.mockResolvedValue({ data: { user: { id: "user-1" } } });
    supabaseMock.current.enqueue("keyword_locations", {
      data: {
        id: LOCATION_ID,
        latitude: -15.8,
        longitude: -47.9,
        keyword_id: KEYWORD_ID,
        keywords: {
          id: KEYWORD_ID,
          term: "troca de bateria",
          business_id: BIZ_ID,
          businesses: { id: BIZ_ID, google_place_id: "place-alvo" },
        },
      },
      error: null,
    });
    supabaseMock.current.enqueue("ranking_scans", {
      data: { id: "scan-travado", started_at: new Date(Date.now() - 10 * 60 * 1000).toISOString() },
      error: null,
    }); // checagem: encontra o travado
    supabaseMock.current.enqueue("ranking_scans", { error: null }); // update marcando o travado como failed
    supabaseMock.current.enqueue("ranking_scans", { data: { id: "scan-novo" }, error: null }); // insert do novo
    supabaseMock.current.enqueue("ranking_grid_points", {
      data: [{ id: "point-0", row_index: 0, col_index: 0, latitude: -15.8, longitude: -47.9 }],
      error: null,
    });
    searchTextAtLocationMock.mockResolvedValue({ places: [{ placeId: "place-alvo" }], fromCache: false });
    persistConfirmedPlaceMock.mockResolvedValue(true);

    const result = await runRankingScanAction(LOCATION_ID, "3x3");
    expect(result).toEqual({ ok: true, scanId: "scan-novo" });
  });

  it("roda um scan 3x3 completo com sucesso (9 pontos)", async () => {
    isGooglePlacesConfiguredMock.mockReturnValue(true);
    supabaseMock.current.auth.getUser.mockResolvedValue({ data: { user: { id: "user-1" } } });
    supabaseMock.current.enqueue("keyword_locations", {
      data: {
        id: LOCATION_ID,
        latitude: -15.8,
        longitude: -47.9,
        keyword_id: KEYWORD_ID,
        keywords: {
          id: KEYWORD_ID,
          term: "troca de bateria",
          business_id: BIZ_ID,
          businesses: { id: BIZ_ID, google_place_id: "place-alvo" },
        },
      },
      error: null,
    });
    supabaseMock.current.enqueue("ranking_scans", { data: null, error: null }); // checagem: nenhum scan em andamento
    supabaseMock.current.enqueue("ranking_scans", { data: { id: "scan-1" }, error: null });
    supabaseMock.current.enqueue("ranking_grid_points", {
      data: Array.from({ length: 9 }, (_, i) => ({
        id: `point-${i}`,
        row_index: Math.floor(i / 3),
        col_index: i % 3,
        latitude: -15.8,
        longitude: -47.9,
      })),
      error: null,
    });

    searchTextAtLocationMock.mockResolvedValue({
      places: [{ placeId: "place-alvo" }, { placeId: "place-concorrente" }],
      fromCache: false,
    });
    persistConfirmedPlaceMock.mockResolvedValue(true);

    const result = await runRankingScanAction(LOCATION_ID, "3x3");
    expect(result).toEqual({ ok: true, scanId: "scan-1" });
    expect(searchTextAtLocationMock).toHaveBeenCalledTimes(9);

    const resultInserts = supabaseMock.current.calls.filter((c) => c.table === "ranking_results" && c.method === "insert");
    expect(resultInserts).toHaveLength(9);
  });

  it("registra 'não encontrado' em vez de derrubar o scan quando um ponto falha", async () => {
    isGooglePlacesConfiguredMock.mockReturnValue(true);
    supabaseMock.current.auth.getUser.mockResolvedValue({ data: { user: { id: "user-1" } } });
    supabaseMock.current.enqueue("keyword_locations", {
      data: {
        id: LOCATION_ID,
        latitude: -15.8,
        longitude: -47.9,
        keyword_id: KEYWORD_ID,
        keywords: {
          id: KEYWORD_ID,
          term: "troca de bateria",
          business_id: BIZ_ID,
          businesses: { id: BIZ_ID, google_place_id: "place-alvo" },
        },
      },
      error: null,
    });
    supabaseMock.current.enqueue("ranking_scans", { data: null, error: null }); // checagem: nenhum scan em andamento
    supabaseMock.current.enqueue("ranking_scans", { data: { id: "scan-1" }, error: null });
    supabaseMock.current.enqueue("ranking_grid_points", {
      data: [{ id: "point-0", row_index: 0, col_index: 0, latitude: -15.8, longitude: -47.9 }],
      error: null,
    });

    searchTextAtLocationMock.mockRejectedValue(new Error("timeout"));

    const result = await runRankingScanAction(LOCATION_ID, "3x3");
    expect(result).toEqual({ ok: true, scanId: "scan-1" });

    const [resultInsertCall] = supabaseMock.current.calls.filter(
      (c) => c.table === "ranking_results" && c.method === "insert"
    );
    expect(resultInsertCall).toBeTruthy();
  });
});
