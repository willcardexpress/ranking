import { describe, expect, it, vi, beforeEach } from "vitest";

const redirectMock = vi.fn((path: string) => {
  throw new Error(`REDIRECT:${path}`);
});
vi.mock("next/navigation", () => ({ redirect: (path: string) => redirectMock(path) }));

const signUpMock = vi.fn();
const createClientMock = vi.fn(() => Promise.resolve({ auth: { signUp: signUpMock } }));
vi.mock("@/lib/supabase/server", () => ({
  createClient: () => createClientMock(),
}));

const { signUp } = await import("@/lib/supabase/actions");

function formData(fields: Record<string, string>) {
  const fd = new FormData();
  for (const [k, v] of Object.entries(fields)) fd.set(k, v);
  return fd;
}

const VALID_FIELDS = { email: "user@exemplo.com", password: "senha12345", organizationName: "Agência X" };

beforeEach(() => {
  redirectMock.mockClear();
  signUpMock.mockReset();
});

describe("signUp", () => {
  it("rejeita dados inválidos antes de chamar o Supabase", async () => {
    const result = await signUp(null, formData({ ...VALID_FIELDS, email: "não-é-email" }));
    expect(result?.error).toBeTruthy();
    expect(signUpMock).not.toHaveBeenCalled();
  });

  it("retorna erro genérico quando o Supabase recusa o cadastro", async () => {
    signUpMock.mockResolvedValue({ data: { session: null }, error: { message: "e-mail já cadastrado" } });
    const result = await signUp(null, formData(VALID_FIELDS));
    expect(result?.error).toBe("Não foi possível criar a conta. Tente novamente.");
  });

  it("pede confirmação de e-mail quando o Supabase não retorna sessão (confirmação habilitada)", async () => {
    signUpMock.mockResolvedValue({ data: { session: null, user: { id: "user-1" } }, error: null });
    const result = await signUp(null, formData(VALID_FIELDS));
    expect(result).toEqual({ needsEmailConfirmation: true });
    expect(redirectMock).not.toHaveBeenCalled();
  });

  it("redireciona para /dashboard quando o Supabase já retorna sessão (confirmação desabilitada)", async () => {
    signUpMock.mockResolvedValue({ data: { session: { access_token: "x" } }, error: null });
    await expect(signUp(null, formData(VALID_FIELDS))).rejects.toThrow("REDIRECT:/dashboard");
  });
});
