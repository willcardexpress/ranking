import { describe, expect, it } from "vitest";
import { runWithTimeout, TimeoutError } from "@/lib/with-timeout";

function delay<T>(ms: number, value: T): Promise<T> {
  return new Promise((resolve) => setTimeout(() => resolve(value), ms));
}

describe("runWithTimeout", () => {
  it("resolve normalmente quando a operação termina antes do limite", async () => {
    const result = await runWithTimeout(delay(10, "ok"), 100);
    expect(result).toBe("ok");
  });

  it("rejeita com TimeoutError quando a operação demora mais que o limite", async () => {
    await expect(runWithTimeout(delay(200, "tarde demais"), 20)).rejects.toBeInstanceOf(TimeoutError);
  });

  it("propaga o erro original quando a própria operação falha antes do timeout", async () => {
    const failing = Promise.reject(new Error("falha real"));
    await expect(runWithTimeout(failing, 100)).rejects.toThrow("falha real");
  });

  it("usa a mensagem customizada quando fornecida", async () => {
    await expect(runWithTimeout(delay(200, "x"), 10, "excedeu o tempo do scan")).rejects.toThrow(
      "excedeu o tempo do scan"
    );
  });
});
